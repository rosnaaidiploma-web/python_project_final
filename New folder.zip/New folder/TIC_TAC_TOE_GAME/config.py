WINDOW_WIDTH = 900
WINDOW_HEIGHT = 700

BACKGROUND = "#0B1020"
CARD = "#151B30"
CARD_2 = "#1D2540"
PRIMARY = "#6C63FF"
SECONDARY = "#00D4FF"
SUCCESS = "#35E08F"
DANGER = "#FF5577"
WARNING = "#FFC857"
WHITE = "#FFFFFF"
GRAY = "#A7AEC4"

TOTAL_LEVELS = 8

LEVELS = {
    1: {"name": "Easy", "time": 60, "reward": 100, "ai": "random"},
    2: {"name": "Easy+", "time": 55, "reward": 150, "ai": "basic"},
    3: {"name": "Normal", "time": 50, "reward": 200, "ai": "basic"},
    4: {"name": "Defensive", "time": 45, "reward": 250, "ai": "defensive"},
    5: {"name": "Hard", "time": 40, "reward": 300, "ai": "offensive"},
    6: {"name": "Expert", "time": 35, "reward": 400, "ai": "minimax"},
    7: {"name": "Advanced", "time": 30, "reward": 500, "ai": "minimax"},
    8: {"name": "Master", "time": 25, "reward": 1000, "ai": "minimax"},
}
