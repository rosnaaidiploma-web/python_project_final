class GameTimer:
    def __init__(self, root, seconds, on_tick, on_finish):
        self.root = root
        self.remaining = seconds
        self.on_tick = on_tick
        self.on_finish = on_finish
        self.running = False
        self.job = None

    def start(self):
        self.running = True
        self.tick()

    def tick(self):
        if not self.running:
            return
        self.on_tick(self.remaining)
        if self.remaining <= 0:
            self.running = False
            self.on_finish()
            return
        self.remaining -= 1
        self.job = self.root.after(1000, self.tick)

    def stop(self):
        self.running = False
        if self.job:
            try:
                self.root.after_cancel(self.job)
            except Exception:
                pass
            self.job = None
