from game.board import Board

class GameLogic:
    def __init__(self, human_symbol="O"):
        self.human = human_symbol
        self.ai = "X" if human_symbol == "O" else "O"
        self.board = Board()

    def reset(self):
        self.board.reset()

    def play(self, index, symbol):
        return self.board.make_move(index, symbol)

    def result(self):
        return self.board.winner()
