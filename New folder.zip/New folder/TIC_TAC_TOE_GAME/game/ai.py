import random

WIN_LINES = [
    (0,1,2),(3,4,5),(6,7,8),
    (0,3,6),(1,4,7),(2,5,8),
    (0,4,8),(2,4,6)
]

def find_winning_move(cells, symbol):
    for i in range(9):
        if not cells[i]:
            test = cells[:]
            test[i] = symbol
            if winner(test) == symbol:
                return i
    return None

def winner(cells):
    for a,b,c in WIN_LINES:
        if cells[a] and cells[a] == cells[b] == cells[c]:
            return cells[a]
    return "DRAW" if all(cells) else None

def minimax(cells, maximizing, ai, human):
    result = winner(cells)
    if result == ai:
        return 1
    if result == human:
        return -1
    if result == "DRAW":
        return 0

    scores = []
    for i in range(9):
        if not cells[i]:
            cells[i] = ai if maximizing else human
            scores.append(minimax(cells, not maximizing, ai, human))
            cells[i] = ""
    return max(scores) if maximizing else min(scores)

def best_minimax(cells, ai, human):
    best_score = -999
    best_move = None
    for i in range(9):
        if not cells[i]:
            cells[i] = ai
            score = minimax(cells, False, ai, human)
            cells[i] = ""
            if score > best_score:
                best_score = score
                best_move = i
    return best_move

def choose_move(cells, ai, human, mode):
    available = [i for i, x in enumerate(cells) if not x]
    if not available:
        return None

    if mode == "random":
        return random.choice(available)

    win = find_winning_move(cells, ai)
    block = find_winning_move(cells, human)

    if mode == "basic":
        return win if win is not None else random.choice(available)

    if mode == "defensive":
        return win if win is not None else (block if block is not None else random.choice(available))

    if mode == "offensive":
        if win is not None:
            return win
        if 4 in available:
            return 4
        return block if block is not None else random.choice(available)

    return best_minimax(cells, ai, human)
