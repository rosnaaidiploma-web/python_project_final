from config import LEVELS

def get_level(level):
    level = max(1, min(8, int(level)))
    return LEVELS[level]
