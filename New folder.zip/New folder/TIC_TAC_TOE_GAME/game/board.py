class Board:
    def __init__(self):
        self.reset()

    def reset(self):
        self.cells = [""] * 9

    def available(self):
        return [i for i, value in enumerate(self.cells) if not value]

    def make_move(self, index, symbol):
        if index not in range(9) or self.cells[index]:
            return False
        self.cells[index] = symbol
        return True

    def winner(self):
        lines = [
            (0,1,2),(3,4,5),(6,7,8),
            (0,3,6),(1,4,7),(2,5,8),
            (0,4,8),(2,4,6)
        ]
        for a,b,c in lines:
            if self.cells[a] and self.cells[a] == self.cells[b] == self.cells[c]:
                return self.cells[a], (a,b,c)
        if all(self.cells):
            return "DRAW", ()
        return None, ()

    def is_full(self):
        return not self.available()
