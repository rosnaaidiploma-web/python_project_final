class Score:
    def __init__(self, value=0):
        self.value = value

    def add(self, points):
        self.value += points
        return self.value
