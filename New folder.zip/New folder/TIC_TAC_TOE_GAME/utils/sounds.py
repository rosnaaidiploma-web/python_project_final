import os
import wave
import struct

try:
    import winsound
except ImportError:
    winsound = None

def play_sound(filename):
    path = os.path.join("assets", "sounds", filename)
    if winsound and os.path.exists(path):
        try:
            winsound.PlaySound(path, winsound.SND_FILENAME | winsound.SND_ASYNC)
        except Exception:
            pass

def create_beep(path, frequency=700, duration_ms=100):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    rate = 44100
    samples = int(rate * duration_ms / 1000)
    with wave.open(path, "w") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(rate)
        for i in range(samples):
            value = int(12000 * math_sin(2 * 3.14159265 * frequency * i / rate))
            wav.writeframes(struct.pack("<h", value))

def math_sin(x):
    import math
    return math.sin(x)
