def pulse(widget, root, colors, index=0):
    if not widget.winfo_exists():
        return
    widget.configure(fg=colors[index % len(colors)])
    root.after(350, pulse, widget, root, colors, index + 1)
