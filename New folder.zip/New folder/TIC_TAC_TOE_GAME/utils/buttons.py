import tkinter as tk
from config import PRIMARY, SECONDARY, WHITE, CARD_2

def game_button(parent, text, command, width=22):
    button = tk.Button(
        parent, text=text, command=command,
        font=("Segoe UI", 13, "bold"),
        width=width, height=2,
        bg=PRIMARY, fg=WHITE,
        activebackground=SECONDARY,
        activeforeground=WHITE,
        relief="flat", bd=0, cursor="hand2"
    )
    button.bind("<Enter>", lambda e: button.configure(bg=SECONDARY))
    button.bind("<Leave>", lambda e: button.configure(bg=PRIMARY))
    return button
