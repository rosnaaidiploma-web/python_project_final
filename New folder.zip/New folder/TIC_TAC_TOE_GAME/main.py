import tkinter as tk
from screens.loading import LoadingScreen

class TicTacToeApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Tic Tac Toe - O X")
        self.root.geometry("900x700")
        self.root.minsize(700, 600)
        self.root.configure(bg="#0B1020")
        self.player_name = ""
        self.player_symbol = "O"
        self.current_level = 1
        self.score = 0
        self.progress = self.load_progress()
        self.show_loading()

    def load_progress(self):
        import json, os
        path = "data/game_progress.json"
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {"unlocked": 1, "score": 0, "completed": []}

    def save_progress(self):
        import json
        with open("data/game_progress.json", "w", encoding="utf-8") as f:
            json.dump(self.progress, f, indent=2)

    def clear_screen(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def show_loading(self):
        self.clear_screen()
        LoadingScreen(self)

if __name__ == "__main__":
    root = tk.Tk()
    app = TicTacToeApp(root)
    root.mainloop()
