import tkinter as tk
from config import *
from utils.fonts import BOARD
from utils.sounds import play_sound
from game.game_logic import GameLogic
from game.ai import choose_move
from game.levels import get_level
from game.timer import GameTimer

class GameScreen:
    def __init__(self, app):
        self.app = app
        self.level = app.current_level
        self.info = get_level(self.level)
        self.logic = GameLogic(app.player_symbol)
        self.game_over = False
        self.buttons = []

        self.frame = tk.Frame(app.root, bg=BACKGROUND)
        self.frame.pack(fill="both", expand=True)

        header = tk.Frame(self.frame, bg=BACKGROUND)
        header.pack(fill="x", padx=35, pady=20)
        tk.Label(header, text=f"LEVEL {self.level} • {self.info['name'].upper()}",
                 font=("Segoe UI", 18, "bold"), fg=WHITE, bg=BACKGROUND).pack(side="left")
        self.timer_label = tk.Label(header, text="", font=("Segoe UI", 18, "bold"),
                                    fg=WARNING, bg=BACKGROUND)
        self.timer_label.pack(side="right")

        tk.Label(self.frame, text=f"{app.player_name} ({app.player_symbol})  VS  AI ({self.logic.ai})",
                 font=("Segoe UI", 13), fg=GRAY, bg=BACKGROUND).pack(pady=5)

        self.status = tk.Label(self.frame, text="YOUR TURN",
                               font=("Segoe UI", 15, "bold"), fg=SECONDARY, bg=BACKGROUND)
        self.status.pack(pady=10)

        board = tk.Frame(self.frame, bg=BACKGROUND)
        board.pack(pady=12)

        for i in range(9):
            b = tk.Button(board, text="", font=BOARD, width=4, height=2,
                          bg=CARD, fg=WHITE, activebackground=CARD_2,
                          activeforeground=WHITE, relief="flat", bd=2,
                          command=lambda idx=i: self.human_move(idx))
            b.grid(row=i//3, column=i%3, padx=5, pady=5)
            b.bind("<Enter>", lambda e, btn=b: btn.configure(bg=CARD_2))
            b.bind("<Leave>", lambda e, btn=b: btn.configure(bg=CARD))
            self.buttons.append(b)

        bottom = tk.Frame(self.frame, bg=BACKGROUND)
        bottom.pack(pady=15)
        tk.Label(bottom, text=f"REWARD: {self.info['reward']}   •   SCORE: {app.progress.get('score',0)}",
                 font=("Segoe UI", 12, "bold"), fg=WARNING, bg=BACKGROUND).pack()
        tk.Button(bottom, text="QUIT LEVEL", command=self.quit_level,
                  font=("Segoe UI", 11, "bold"), bg=DANGER, fg=WHITE,
                  relief="flat").pack(pady=10)

        self.timer = GameTimer(self.app.root, self.info["time"],
                               self.update_timer, self.timeout)
        self.timer.start()

    def update_timer(self, seconds):
        self.timer_label.config(text=f"TIME  {seconds:02d}s",
                                fg=DANGER if seconds <= 10 else WARNING)

    def human_move(self, index):
        if self.game_over or self.logic.board.cells[index]:
            return
        self.logic.play(index, self.app.player_symbol)
        self.buttons[index].config(text=self.app.player_symbol,
                                   fg=PRIMARY if self.app.player_symbol == "O" else SECONDARY,
                                   bg=CARD_2)
        play_sound("move.wav")
        if self.check_end():
            return

        self.status.config(text="AI THINKING...", fg=WARNING)
        self.app.root.after(350, self.ai_move)

    def ai_move(self):
        if self.game_over:
            return
        move = choose_move(self.logic.board.cells, self.logic.ai,
                           self.logic.human, self.info["ai"])
        if move is not None:
            self.logic.play(move, self.logic.ai)
            self.buttons[move].config(text=self.logic.ai,
                                      fg=PRIMARY if self.logic.ai == "O" else SECONDARY,
                                      bg=CARD_2)
            play_sound("move.wav")
        self.check_end()
        if not self.game_over:
            self.status.config(text="YOUR TURN", fg=SECONDARY)

    def check_end(self):
        result, line = self.logic.result()
        if not result:
            return False
        self.game_over = True
        self.timer.stop()

        if result == "DRAW":
            self.show_result("DRAW", 0)
        elif result == self.app.player_symbol:
            for idx in line:
                self.buttons[idx].config(bg=SUCCESS, fg=BACKGROUND)
            self.show_result("WIN", self.info["reward"])
        else:
            self.show_result("FAIL", 0)
        return True

    def timeout(self):
        if not self.game_over:
            self.game_over = True
            self.show_result("TIME UP", 0)

    def show_result(self, outcome, reward):
        from screens.result import ResultScreen
        self.app.progress["last_result"] = outcome
        self.app.progress["last_reward"] = reward
        self.app.progress["last_level"] = self.level
        self.app.clear_screen()
        ResultScreen(self.app)

    def quit_level(self):
        self.timer.stop()
        from screens.level_select import LevelSelectScreen
        self.app.clear_screen()
        LevelSelectScreen(self.app)
