import tkinter as tk
from config import *
from utils.fonts import TITLE, SUBTITLE

class LoadingScreen:
    def __init__(self, app):
        self.app = app
        self.progress = 0
        self.frame = tk.Frame(app.root, bg=BACKGROUND)
        self.frame.pack(fill="both", expand=True)

        tk.Label(self.frame, text="O   X", font=("Segoe UI", 58, "bold"),
                 fg=PRIMARY, bg=BACKGROUND).pack(pady=(150, 15))
        self.title = tk.Label(self.frame, text="TIC TAC TOE",
                              font=TITLE, fg=WHITE, bg=BACKGROUND)
        self.title.pack()
        tk.Label(self.frame, text="ULTIMATE O & X CHALLENGE",
                 font=SUBTITLE, fg=GRAY, bg=BACKGROUND).pack(pady=6)

        self.bar = tk.Canvas(self.frame, width=420, height=20,
                             bg=CARD, highlightthickness=0)
        self.bar.pack(pady=35)
        self.label = tk.Label(self.frame, text="Loading... 0%",
                              font=SUBTITLE, fg=WHITE, bg=BACKGROUND)
        self.label.pack()
        self.load()

    def load(self):
        if self.progress <= 100:
            self.bar.delete("all")
            self.bar.create_rectangle(0, 0, 4.2*self.progress, 20,
                                      fill=SECONDARY, outline="")
            self.label.config(text=f"Loading... {self.progress}%")
            self.progress += 4
            self.app.root.after(45, self.load)
        else:
            from screens.home import HomeScreen
            self.app.clear_screen()
            HomeScreen(self.app)
