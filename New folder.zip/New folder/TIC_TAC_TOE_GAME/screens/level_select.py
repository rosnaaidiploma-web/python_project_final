import tkinter as tk
from config import *
from utils.buttons import game_button 

class LevelSelectScreen:
    def __init__(self, app):
        self.app = app
        self.frame = tk.Frame(app.root, bg=BACKGROUND)
        self.frame.pack(fill="both", expand=True)

        tk.Label(self.frame, text="SELECT LEVEL", font=("Segoe UI", 30, "bold"),
                 fg=WHITE, bg=BACKGROUND).pack(pady=35)

        grid = tk.Frame(self.frame, bg=BACKGROUND)
        grid.pack()

        unlocked = int(app.progress.get("unlocked", 1))
        completed = app.progress.get("completed", [])

        for level in range(1, 9):
            row = (level - 1) // 4
            col = (level - 1) % 4
            is_open = level <= unlocked
            text = f"LEVEL {level}\n{' PASSED' if level in completed else ('UNLOCKED' if is_open else ' LOCKED')}"
            b = tk.Button(grid, text=text,
                          command=lambda lv=level: self.start(lv),
                          font=("Segoe UI", 11, "bold"),
                          width=13, height=4,
                          bg=CARD if is_open else "#111625",
                          fg=SUCCESS if level in completed else (WHITE if is_open else GRAY),
                          activebackground=PRIMARY,
                          relief="flat", state="normal" if is_open else "disabled")
            b.grid(row=row, column=col, padx=8, pady=8)

        tk.Label(self.frame, text=f"TOTAL SCORE: {app.progress.get('score', 0)}",
                 font=("Segoe UI", 14, "bold"), fg=WARNING, bg=BACKGROUND).pack(pady=18)
        game_button(self.frame, "BACK", self.back).pack()

    def start(self, level):
        self.app.current_level = level
        from screens.game import GameScreen
        self.app.clear_screen()
        GameScreen(self.app)

    def back(self):
        from screens.players import PlayersScreen
        self.app.clear_screen()
        PlayersScreen(self.app)
