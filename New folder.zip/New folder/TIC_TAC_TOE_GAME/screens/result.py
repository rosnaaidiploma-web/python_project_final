import tkinter as tk
from config import *
from utils.buttons import game_button
from utils.sounds import play_sound

class ResultScreen:
    def __init__(self, app):
        self.app = app
        result = app.progress.get("last_result", "FAIL")
        reward = app.progress.get("last_reward", 0)
        level = app.progress.get("last_level", 1)

        if result == "WIN":
            title, color, message = "YOU WIN!", SUCCESS, f"LEVEL {level} PASSED"
            play_sound("win.wav")
            if level not in app.progress.get("completed", []):
                app.progress.setdefault("completed", []).append(level)
            app.progress["score"] = app.progress.get("score", 0) + reward
            if level < 8:
                app.progress["unlocked"] = max(app.progress.get("unlocked", 1), level + 1)
            app.save_progress()
        elif result == "DRAW":
            title, color, message = "DRAW", WARNING, f"LEVEL {level} NOT COMPLETED"
        else:
            title, color, message = "LEVEL FAILED", DANGER, f"LEVEL {level} - TRY AGAIN"
            play_sound("lose.wav")

        self.frame = tk.Frame(app.root, bg=BACKGROUND)
        self.frame.pack(fill="both", expand=True)

        tk.Label(self.frame, text="★" if result == "WIN" else "O X",
                 font=("Segoe UI", 65, "bold"), fg=color, bg=BACKGROUND).pack(pady=(100, 10))
        tk.Label(self.frame, text=title, font=("Segoe UI", 34, "bold"),
                 fg=color, bg=BACKGROUND).pack()
        tk.Label(self.frame, text=message, font=("Segoe UI", 16, "bold"),
                 fg=WHITE, bg=BACKGROUND).pack(pady=15)

        if result == "WIN":
            tk.Label(self.frame, text=f"+{reward} POINTS\nTOTAL SCORE: {app.progress['score']}",
                     font=("Segoe UI", 16, "bold"), fg=WARNING, bg=BACKGROUND).pack(pady=10)

        if result == "WIN" and level == 8:
            game_button(self.frame, "VIEW FINAL RESULT", self.final).pack(pady=30)
        elif result == "WIN":
            game_button(self.frame, "NEXT LEVEL", self.next_level).pack(pady=30)
        else:
            game_button(self.frame, "RETRY", self.retry).pack(pady=30)

        game_button(self.frame, "LEVEL SELECT", self.levels).pack(pady=8)
        game_button(self.frame, "HOME", self.home).pack(pady=8)

    def next_level(self):
        self.app.current_level += 1
        from screens.game import GameScreen
        self.app.clear_screen()
        GameScreen(self.app)

    def retry(self):
        from screens.game import GameScreen
        self.app.clear_screen()
        GameScreen(self.app)

    def levels(self):
        from screens.level_select import LevelSelectScreen
        self.app.clear_screen()
        LevelSelectScreen(self.app)

    def home(self):
        from screens.home import HomeScreen
        self.app.clear_screen()
        HomeScreen(self.app)

    def final(self):
        from screens.final_result import FinalResultScreen
        self.app.clear_screen()
        FinalResultScreen(self.app)
