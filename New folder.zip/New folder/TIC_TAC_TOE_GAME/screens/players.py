import tkinter as tk
from config import *
from utils.buttons import game_button

class PlayersScreen:
    def __init__(self, app):
        self.app = app
        self.frame = tk.Frame(app.root, bg=BACKGROUND)
        self.frame.pack(fill="both", expand=True)

        tk.Label(self.frame, text="PLAYERS", font=("Segoe UI", 30, "bold"),
                 fg=WHITE, bg=BACKGROUND).pack(pady=55)

        row = tk.Frame(self.frame, bg=BACKGROUND)
        row.pack(pady=15)

        self.card(row, app.player_name, app.player_symbol, "PLAYER")
        tk.Label(row, text="VS", font=("Segoe UI", 22, "bold"),
                 fg=SECONDARY, bg=BACKGROUND).pack(side="left", padx=35)
        ai_symbol = "X" if app.player_symbol == "O" else "O"
        self.card(row, "SMART AI", ai_symbol, "COMPUTER")

        game_button(self.frame, "SELECT LEVEL", self.levels).pack(pady=40)
        game_button(self.frame, "BACK", self.back).pack()

    def card(self, parent, name, symbol, role):
        c = tk.Frame(parent, bg=CARD, width=240, height=180)
        c.pack_propagate(False)
        c.pack(side="left")
        tk.Label(c, text=role, font=("Segoe UI", 11, "bold"),
                 fg=GRAY, bg=CARD).pack(pady=(18, 4))
        tk.Label(c, text=symbol, font=("Segoe UI", 48, "bold"),
                 fg=PRIMARY if symbol == "O" else SECONDARY, bg=CARD).pack()
        tk.Label(c, text=name, font=("Segoe UI", 14, "bold"),
                 fg=WHITE, bg=CARD).pack()

    def levels(self):
        from screens.level_select import LevelSelectScreen
        self.app.clear_screen()
        LevelSelectScreen(self.app)

    def back(self):
        from screens.registration import RegistrationScreen
        self.app.clear_screen()
        RegistrationScreen(self.app)
