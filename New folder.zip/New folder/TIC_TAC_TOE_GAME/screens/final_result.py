import tkinter as tk
from config import *
from utils.buttons import game_button

class FinalResultScreen:
    def __init__(self, app):
        self.app = app
        self.frame = tk.Frame(app.root, bg=BACKGROUND)
        self.frame.pack(fill="both", expand=True)

        tk.Label(self.frame, text="🏆", font=("Segoe UI", 70),
                 fg=WARNING, bg=BACKGROUND).pack(pady=(80, 10))
        tk.Label(self.frame, text="CONGRATULATIONS!",
                 font=("Segoe UI", 32, "bold"), fg=SUCCESS, bg=BACKGROUND).pack()
        tk.Label(self.frame, text="MASTER LEVEL COMPLETE",
                 font=("Segoe UI", 16, "bold"), fg=WHITE, bg=BACKGROUND).pack(pady=10)
        tk.Label(self.frame, text=f"{app.player_name}",
                 font=("Segoe UI", 20, "bold"), fg=SECONDARY, bg=BACKGROUND).pack(pady=10)
        tk.Label(self.frame, text=f"FINAL SCORE\n{app.progress.get('score',0)}",
                 font=("Segoe UI", 22, "bold"), fg=WARNING, bg=BACKGROUND).pack(pady=20)

        game_button(self.frame, "PLAY AGAIN", self.play_again).pack(pady=12)
        game_button(self.frame, "HOME", self.home).pack(pady=8)

    def play_again(self):
        self.app.current_level = 1
        from screens.game import GameScreen
        self.app.clear_screen()
        GameScreen(self.app)

    def home(self):
        from screens.home import HomeScreen
        self.app.clear_screen()
        HomeScreen(self.app)
