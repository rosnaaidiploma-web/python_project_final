import tkinter as tk
from config import *
from utils.buttons import game_button

class RegistrationScreen:
    def __init__(self, app):
        self.app = app
        self.frame = tk.Frame(app.root, bg=BACKGROUND)
        self.frame.pack(fill="both", expand=True)

        tk.Label(self.frame, text="PLAYER REGISTRATION",
                 font=("Segoe UI", 28, "bold"), fg=WHITE, bg=BACKGROUND).pack(pady=70)

        tk.Label(self.frame, text="Player name", fg=GRAY, bg=BACKGROUND,
                 font=("Segoe UI", 13)).pack()
        self.name = tk.Entry(self.frame, font=("Segoe UI", 16),
                             width=25, justify="center")
        self.name.pack(pady=10)

        tk.Label(self.frame, text="Choose your symbol", fg=GRAY,
                 bg=BACKGROUND, font=("Segoe UI", 13)).pack(pady=(20, 8))

        self.symbol = tk.StringVar(value="O")
        box = tk.Frame(self.frame, bg=BACKGROUND)
        box.pack()
        tk.Radiobutton(box, text="  O  ", variable=self.symbol, value="O",
                       font=("Segoe UI", 18, "bold"), bg=CARD, fg=PRIMARY,
                       selectcolor=CARD, activebackground=CARD).pack(side="left", padx=8)
        tk.Radiobutton(box, text="  X  ", variable=self.symbol, value="X",
                       font=("Segoe UI", 18, "bold"), bg=CARD, fg=SECONDARY,
                       selectcolor=CARD, activebackground=CARD).pack(side="left", padx=8)

        game_button(self.frame, "CONTINUE", self.continue_game).pack(pady=35)
        game_button(self.frame, "BACK", self.back).pack()

    def continue_game(self):
        name = self.name.get().strip()
        if not name:
            from tkinter import messagebox
            messagebox.showwarning("Name required", "Please enter your name.")
            return
        self.app.player_name = name
        self.app.player_symbol = self.symbol.get()

        import json
        with open("data/players.json", "w", encoding="utf-8") as f:
            json.dump({"name": name, "symbol": self.app.player_symbol}, f, indent=2)

        from screens.players import PlayersScreen
        self.app.clear_screen()
        PlayersScreen(self.app)

    def back(self):
        from screens.home import HomeScreen
        self.app.clear_screen()
        HomeScreen(self.app)
