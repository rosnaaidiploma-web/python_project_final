import tkinter as tk
from config import *
from utils.buttons import game_button
from utils.fonts import TITLE, SUBTITLE

class HomeScreen:
    def __init__(self, app):
        self.app = app
        self.frame = tk.Frame(app.root, bg=BACKGROUND)
        self.frame.pack(fill="both", expand=True)

        tk.Label(self.frame, text="O-X", font=("Segoe UI", 62, "bold"),
                 fg=PRIMARY, bg=BACKGROUND).pack(pady=(85, 10))
        tk.Label(self.frame, text="TIC TAC TOE", font=TITLE,
                 fg=WHITE, bg=BACKGROUND).pack()
        tk.Label(self.frame, text="8 LEVELS , SMART AI , TIMED CHALLENGE",
                 font=SUBTITLE, fg=GRAY, bg=BACKGROUND).pack(pady=6)

        game_button(self.frame, "PLAY GAME", self.register).pack(pady=(35, 8))
        game_button(self.frame, "HOW TO PLAY", self.help).pack(pady=8)
        game_button(self.frame, "EXIT", self.app.root.destroy).pack(pady=8)

    def register(self):
        from screens.registration import RegistrationScreen
        self.app.clear_screen()
        RegistrationScreen(self.app)

    def help(self):
        from tkinter import messagebox
        messagebox.showinfo("How to Play",
            "Choose O or X and play against the computer.\n"
            "Make three symbols in a row to win.\n"
            "Pass a level to unlock the next one.\n"
            "Higher levels have stronger AI and shorter timers.")
