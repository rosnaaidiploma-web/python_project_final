# TIC TAC TOE GAME - O & X

A Python Tkinter 8-level Tic-Tac-Toe game with:
- Loading screen
- Attractive dark gaming UI
- Player registration
- O/X selection
- Player vs Smart AI
- 8 levels
- Level locking/unlocking
- Countdown timer
- Hover effects
- Sound effects on Windows
- Scoreboard and saved progress
- Win / draw / fail / retry
- Minimax AI on higher levels
- Final champion screen

## Run on Windows

Open PowerShell in this folder:

    python main.py


## Reset game progress

Delete:

    data/game_progress.json

Then create it again with:

    {
      "unlocked": 1,
      "score": 0,
      "completed": []
    }

