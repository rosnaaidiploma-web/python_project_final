# Legends of the Forgotten Realm

A command-line, turn-based RPG built in Python 3.x from the supplied major-project specification.

## Included

- 4 classes: Warrior, Mage, Archer, Assassin
- Character creation and persistent stats
- Turn-based combat with 8 actions
- Critical hits and 50% defend mechanic
- Class skills with mana costs
- 20 unique weapons across rarity tiers
- 12 armor sets
- 15 potion types: health, mana, mixed, and buffs
- Inventory, equipment, selling, and village shop
- 30 enemy types
- Boss battle every 10 levels
- 10 regions from Village to Demon Realm
- Level progression to 100
- Random loot drops
- JSON save/load
- Input validation and exception handling
- Game-over and victory screens

## Requirements

Python 3.x. No external packages are required.

## Run on Windows

1. Extract the ZIP.
2. Open the project folder.
3. Open PowerShell or Command Prompt.
4. Run:

```powershell
python main.py
```

If `python` is not recognized, try:

```powershell
py main.py
```

## Files

- `main.py` - entry point
- `game.py` - game loop, combat, menus, shop, save/load
- `models.py` - Player and game data classes
- `data.py` - classes, weapons, armor, potions, enemies, bosses
- `README.md` - setup and gameplay guide

## Save

Choose **Save Game** from the world menu. Progress is written to `savegame.json` in the project folder.

## Goal

Defeat each boss at levels 10, 20, 30 ... 100, unlock all regions, reach Level 100, and defeat the Ancient Demon King.
