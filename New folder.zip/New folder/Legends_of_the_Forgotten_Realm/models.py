from dataclasses import dataclass, field
from typing import List, Dict
import random

@dataclass
class Weapon:
    name: str
    rank: str
    damage: int
    crit_bonus: float
    price: int
    required_level: int

@dataclass
class Armor:
    name: str
    rank: str
    defense: int
    hp_bonus: int
    mana_bonus: int
    crit_resistance: float
    price: int
    required_level: int

@dataclass
class Potion:
    name: str
    category: str
    hp: int = 0
    mana: int = 0
    attack: int = 0
    defense: int = 0
    crit: float = 0
    turns: int = 0
    price: int = 0

@dataclass
class Enemy:
    name: str
    level: int
    hp: int
    attack: int
    defense: int
    exp: int
    gold: int
    skills: List[str] = field(default_factory=list)
    boss: bool = False
    special_every: int = 3

@dataclass
class Player:
    name: str
    class_name: str
    level: int = 1
    exp: int = 0
    gold: int = 250
    hp: int = 100
    mana: int = 50
    max_hp: int = 100
    max_mana: int = 50
    attack: int = 15
    defense: int = 8
    crit: float = 0.08
    crit_damage: float = 1.75
    weapon: dict = field(default_factory=lambda: {"name":"Wooden Sword","rank":"Common","damage":5,"crit_bonus":0,"price":40,"required_level":1})
    armor: dict = field(default_factory=lambda: {"name":"Cloth Armor","rank":"Common","defense":2,"hp_bonus":0,"mana_bonus":0,"crit_resistance":0,"price":30,"required_level":1})
    inventory_weapons: List[dict] = field(default_factory=list)
    inventory_armor: List[dict] = field(default_factory=list)
    potions: Dict[str, int] = field(default_factory=dict)
    materials: Dict[str, int] = field(default_factory=dict)
    bosses_defeated: int = 0
    enemies_defeated: int = 0
    region_index: int = 0
    unlocked_skills: List[str] = field(default_factory=list)
    active_buffs: Dict[str, dict] = field(default_factory=dict)

    def effective_attack(self):
        bonus = self.weapon.get("damage", 0)
        buff = self.active_buffs.get("attack", {}).get("value", 0)
        return self.attack + bonus + buff

    def effective_defense(self):
        bonus = self.armor.get("defense", 0)
        buff = self.active_buffs.get("defense", {}).get("value", 0)
        return self.defense + bonus + buff

    def effective_crit(self):
        return self.crit + self.weapon.get("crit_bonus", 0) + self.active_buffs.get("crit", {}).get("value", 0)

    def tick_buffs(self):
        expired = []
        for key, data in self.active_buffs.items():
            data["turns"] -= 1
            if data["turns"] <= 0:
                expired.append(key)
        for key in expired:
            del self.active_buffs[key]
