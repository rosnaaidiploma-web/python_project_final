# Legends of the Forgotten Realm
## Project Objectives, Game Mechanics, Architecture, and Algorithms

## 1. Project Overview

**Legends of the Forgotten Realm** is a command-line, turn-based role-playing game (RPG) developed using Python 3.x. Players create a character, choose a class, explore regions, fight enemies, collect equipment, use potions, earn experience, and defeat bosses.

The game includes four character classes: Warrior, Mage, Archer, and Assassin. Players can progress through 100 levels and explore ten regions, from the Village to the Demon Realm.

The project demonstrates object-oriented programming, random number generation, modular design, input validation, exception handling, and JSON-based save/load functionality. It requires no external Python packages.

## 2. Project Objectives

### 2.1 Primary Objective

To develop an interactive Python-based RPG that provides turn-based combat, character progression, equipment management, exploration, and boss battles.

### 2.2 Specific Objectives

1. **Character creation:** Let players create a character and select one of four classes.
2. **Character progression:** Implement experience points, leveling, and stat progression up to Level 100.
3. **Turn-based combat:** Let players select actions strategically during battles.
4. **Class-specific skills:** Implement abilities with mana costs and class-dependent effects.
5. **Combat mechanics:** Include critical hits, defending, damage calculation, healing, and enemy attacks.
6. **Equipment management:** Provide 20 weapons across rarity tiers and 12 armor sets.
7. **Potion system:** Implement 15 potion types for health, mana, combined recovery, and buffs.
8. **Inventory management:** Allow players to collect, equip, use, and sell items.
9. **Shop system:** Provide a village shop for purchasing equipment and consumables.
10. **Enemy variety:** Create 30 enemy types with different combat characteristics.
11. **Boss battles:** Introduce boss encounters every ten levels, culminating in the Ancient Demon King at Level 100.
12. **Region exploration:** Provide ten progressively challenging regions.
13. **Random loot:** Generate randomized rewards after eligible encounters.
14. **Persistent progress:** Save and load player progress using JSON files.
15. **Reliable execution:** Validate user input and handle common runtime errors.
16. **Victory and game over:** Display suitable outcomes when the final challenge is completed or the player loses all health.

### 2.3 Learning Objectives

This project demonstrates practical applications of:

- Python programming fundamentals.
- Object-oriented programming (OOP).
- Classes, objects, methods, and data structures.
- Conditional statements and loops.
- Functions and modular programming.
- Random number generation.
- File handling and JSON serialization.
- Exception handling and input validation.
- Game-state management and algorithm design.

## 3. Game Mechanics

### 3.1 Character Classes

| Class | General Role | Gameplay Focus |
|---|---|---|
| Warrior | Melee fighter | Physical attacks and defense |
| Mage | Magic user | Spell-based attacks and mana management |
| Archer | Ranged fighter | Precision attacks and tactical damage |
| Assassin | Agile fighter | Critical hits and high-damage opportunities |

Each class can have different starting attributes, skills, and combat advantages.

### 3.2 Character Statistics

The player may have the following statistics:

- **Level:** Current character progression.
- **Experience (XP):** Points earned from eligible encounters.
- **Health (HP):** Determines whether the player can continue fighting.
- **Mana (MP):** Resource consumed by skills.
- **Attack:** Contributes to damage dealt.
- **Defense:** Reduces incoming damage.
- **Gold:** Currency used to buy equipment and potions.

Exact starting statistics and level-up rewards should be defined by the game configuration.

### 3.3 Turn-Based Combat

Combat takes place in alternating turns. During the player's turn, the game presents eight available action choices. A typical action menu may include:

1. Normal attack.
2. Use a class skill.
3. Defend.
4. Use a health potion.
5. Use a mana potion.
6. Use another available potion.
7. Inspect the enemy or combat status.
8. Attempt to escape, when permitted.

The precise behavior of these actions depends on the implementation and current battle state.

After a valid player action, the game checks whether the enemy has been defeated. If the enemy survives and combat has not ended, the enemy takes its turn.

### 3.4 Damage Calculation

A simplified conceptual formula is:

```text
Damage = max(1, Attack + WeaponBonus - EffectiveDefense)
```

Additional modifiers may account for skills, buffs, critical hits, and random variation.

This formula is a proposed design model; the actual implementation should define the exact damage rules.

### 3.5 Critical Hits

Critical hits represent attacks that deal increased damage.

1. Generate a random number.
2. Compare it with the configured critical-hit probability.
3. If the check succeeds, apply the critical damage multiplier.
4. Apply remaining damage modifiers.

For example, an attack dealing 20 damage with a critical multiplier of 1.5 deals 30 damage before other modifiers.

### 3.6 Defending

The defend action reduces damage from an eligible incoming attack. If the reduction is 50%, the calculation can be represented as:

```text
DamageAfterDefense = ceil(IncomingDamage * 0.5)
```

The game should apply and clear the defend state at the correct point in the combat sequence.

### 3.7 Class Skills and Mana

Each class has special skills that provide advantages beyond a normal attack. A skill can define:

- Name and description.
- Mana cost.
- Damage or healing effect.
- Additional effects, such as buffs or critical-hit bonuses.
- Usage restrictions.

Before using a skill, the game checks whether the player has sufficient mana. If not, the action is rejected with an explanatory message.

### 3.8 Weapons and Armor

The equipment system contains 20 weapons divided into rarity tiers and 12 armor sets.

Weapons can increase attack power or provide special bonuses. Armor can increase defense or provide other defensive benefits. The game should verify that an item is in the player's inventory and compatible with the relevant equipment slot before equipping it.

### 3.9 Potions

The game contains 15 potion types organized into four categories:

- Health potions.
- Mana potions.
- Combined health and mana potions.
- Temporary buff potions.

Using a potion applies its effect and decreases its inventory quantity. The game should validate item availability and whether the effect is applicable.

### 3.10 Inventory and Equipment Management

Players can:

- View inventory contents.
- Equip weapons and armor.
- Use potions.
- Sell eligible items.
- Review equipped items and character statistics.

Selling an item updates the inventory and gold balance. Buying an item requires sufficient gold and available inventory capacity, if capacity limits are implemented.

### 3.11 Shop System

A purchase generally follows these steps:

1. Display available items and prices.
2. Accept the player's selection.
3. Validate the selected item.
4. Check whether the player has sufficient gold.
5. Deduct the purchase price.
6. Add the item to the inventory.
7. Display a purchase confirmation.

### 3.12 Enemies and Boss Battles

The game contains 30 enemy types with varying statistics and difficulty levels.

Boss battles occur at Levels 10, 20, 30, and every ten levels thereafter, through Level 100. Bosses should have stronger attributes or distinctive abilities compared with ordinary enemies. Defeating a boss allows the player to progress toward the next stage.

### 3.13 Regions and Exploration

The game includes ten regions, progressing from the Village to the Demon Realm. Each region can define:

- Available enemy encounters.
- Difficulty level.
- Possible rewards.
- Region-specific progression requirements.
- Boss encounter conditions.

The game should prevent progression into locked regions until their required conditions are satisfied.

### 3.14 Level Progression

Players earn experience points from eligible encounters. When the required threshold is reached:

1. Increase the character's level.
2. Apply configured stat improvements.
3. Recalculate level-dependent values.
4. Display the level-up notification.
5. Check whether a new region or feature becomes available.

Progression is capped at Level 100.

### 3.15 Random Loot

After eligible encounters, the game generates possible rewards using random selection. Loot can include gold, weapons, armor, potions, and other configured rewards. Item selection and drop probability should be defined by the loot configuration.

### 3.16 Save and Load

The game stores persistent progress in `savegame.json`. Saved information may include:

- Character name and class.
- Level and experience.
- Current and maximum health and mana.
- Gold.
- Inventory.
- Equipped items.
- Current region and progression.
- Other persistent game-state information.

The save system converts supported Python data structures into JSON. The load system validates the saved structure and restores the game state. Invalid or missing save files should be handled safely.

### 3.17 Victory and Game Over

The game has two main terminal outcomes:

- **Victory:** The player defeats the Ancient Demon King at Level 100.
- **Game Over:** The player's health reaches zero and the game cannot continue.

The game displays the appropriate result and can offer a restart or return-to-menu option.

## 4. System Architecture

The project uses a modular architecture to separate the entry point, gameplay logic, data definitions, and player models.

### 4.1 Project Structure

```text
Legends-of-the-Forgotten-Realm/
├── main.py
├── game.py
├── models.py
├── data.py
├── README.md
├── PROJECT_DOCUMENTATION.md
├── requirements.txt
└── savegame.json
```

### 4.2 Module Responsibilities

#### `main.py` — Entry Point

- Starts the application.
- Initializes required game objects.
- Launches the main game loop.
- Handles top-level termination and unexpected errors.

#### `game.py` — Game Controller

- Manages the main menu and world menu.
- Controls the gameplay loop.
- Processes player actions.
- Runs combat and enemy turns.
- Manages inventory, equipment, and shop interactions.
- Handles progression and boss battles.
- Implements saving and loading.
- Displays victory and game-over screens.

#### `models.py` — Data Models

- Defines the `Player` class.
- Represents player attributes and progression.
- Stores inventory and equipment information.
- Provides methods for updating character statistics.
- Defines additional data classes where appropriate.

#### `data.py` — Game Configuration

- Defines the four character classes.
- Stores weapon and armor definitions.
- Stores potion data.
- Defines enemy and boss statistics.
- Configures regions, rarity tiers, skills, and reward values.

#### `README.md` — User Documentation

- Describes the project and its objectives.
- Explains installation and execution.
- Documents controls and game mechanics.
- Explains save-file behavior and troubleshooting.

#### `requirements.txt` — Dependencies

No third-party dependencies are required. The project uses the Python standard library, including modules such as `random`, `json`, and `math`. The requirements file can therefore be empty or contain an explanatory comment.

#### `savegame.json` — Persistent Data

Stores saved player progress when the player selects the Save Game option. This file is generated at runtime and is not required for a fresh game.

### 4.3 Architecture Diagram

```text
                ┌───────────────────┐
                │      main.py      │
                │  Application Start│
                └─────────┬─────────┘
                          │
                          ▼
                ┌───────────────────┐
                │      game.py      │
                │  Game Controller  │
                └─────────┬─────────┘
                          │
             ┌────────────┼─────────────┐
             ▼            ▼             ▼
      ┌────────────┐ ┌────────────┐ ┌────────────┐
      │  models.py │ │   data.py  │ │ JSON Save  │
      │ Player and │ │ Game Rules │ │ and Load   │
      │ Game Models│ │ and Content│ │ savegame   │
      └────────────┘ └────────────┘ └────────────┘
             │            │             │
             └────────────┼─────────────┘
                          ▼
                ┌───────────────────┐
                │   Game Results    │
                │ Progress / Combat │
                │ Victory / Defeat  │
                └───────────────────┘
```

### 4.4 Architectural Principles

- **Modularity:** Each file has a clear responsibility.
- **Encapsulation:** Player-related data and behavior are organized into classes.
- **Separation of concerns:** Configuration data is separated from game logic.
- **Reusability:** Common operations such as damage calculation and inventory updates can be implemented as reusable methods.
- **Maintainability:** New enemies, items, skills, and regions can be added with minimal changes to the game controller.
- **Persistence:** JSON stores progress between sessions.

## 5. Algorithms

An algorithm is a sequence of steps used to solve a problem or perform a task. The game uses algorithms to control combat, progression, inventory operations, and saving.

### 5.1 Main Game Loop Algorithm

**Purpose:** Keep the game running until the player exits, wins, or loses.

```text
START
    Initialize game

    IF saved game is selected:
        Load and validate save
    ELSE:
        Create new character

    WHILE game is active:
        Display menu
        Read player choice
        Validate choice
        Execute selected action
        Update game state

        IF player has won:
            Display victory
            END GAME

        IF player has lost:
            Display game over
            END GAME

    END WHILE
END
```

### 5.2 Character Creation Algorithm

```text
START CHARACTER CREATION

    Request character name
    Validate character name

    Display four character classes
    Request class selection
    Validate selection

    Create Player object
    Assign starting statistics
    Assign class-specific skills
    Initialize inventory and equipment
    Set starting level and experience

    Display character summary

END CHARACTER CREATION
```

### 5.3 Turn-Based Combat Algorithm

```text
START COMBAT

    Initialize enemy

    WHILE player HP > 0 AND enemy HP > 0:

        Display player and enemy statistics
        Display available actions

        Read player action
        Validate action

        Execute player action
        Apply damage or other effects

        IF enemy HP <= 0:
            Award eligible rewards
            Update experience and progression
            END COMBAT

        IF combat has ended:
            END COMBAT

        Execute enemy action
        Calculate incoming damage
        Apply defense and other modifiers
        Update player HP

        IF player HP <= 0:
            Display game over
            END COMBAT

    END WHILE

END COMBAT
```

### 5.4 Damage Calculation Algorithm

```text
FUNCTION calculate_damage(attacker, defender, modifiers):

    Calculate base attack damage
    Apply weapon and skill bonuses
    Apply critical-hit check
    Apply relevant damage modifiers
    Subtract effective defense
    Ensure damage follows the game's minimum rules

    RETURN final damage
```

The implementation should define the order in which critical hits, buffs, defense, and rounding are applied.

### 5.5 Defend Algorithm

```text
FUNCTION apply_defend(incoming_damage):

    reduced_damage = CEILING(incoming_damage * 0.5)

    RETURN reduced_damage
```

The defend state must be applied and cleared at the correct point in combat so it does not unintentionally last longer than intended.

### 5.6 Class Skill Algorithm

```text
FUNCTION use_skill(player, skill, target):

    IF skill is not available to player:
        Reject action

    ELSE IF player mana < skill mana cost:
        Display insufficient mana
        Reject action

    ELSE:
        Deduct skill mana cost
        Apply skill effect to target
        Update affected statistics
        Display result

    END IF
```

### 5.7 Level-Up Algorithm

```text
FUNCTION process_level_up(player):

    WHILE player level < 100
          AND player XP >= required XP:

        Deduct or account for required XP
        Increase player level
        Apply configured stat increases
        Update maximum health and mana
        Display level-up message

    END WHILE

    Check region and progression unlocks
```

The experience formula and whether excess experience carries over must be defined by the implementation.

### 5.8 Random Loot Algorithm

```text
FUNCTION generate_loot(enemy):

    Determine loot eligibility
    Generate random drop result

    IF a reward is generated:
        Select an eligible item
        Add reward to inventory
        Display reward message
    ELSE:
        Display no loot message
    END IF
```

Drop rates and item rarity probabilities are configurable game-design parameters.

### 5.9 Inventory Algorithm

```text
FUNCTION manage_inventory(player, action, item):

    Validate requested action
    Verify item exists in inventory

    IF action is EQUIP:
        Check equipment compatibility
        Equip item
        Update relevant statistics

    ELSE IF action is USE:
        Check item requirements
        Apply item effect
        Update item quantity

    ELSE IF action is SELL:
        Check item can be sold
        Remove or reduce item quantity
        Add sale value to gold

    END IF

    Display updated inventory
```

### 5.10 Save and Load Algorithm

**Save:**

```text
FUNCTION save_game(player, game_state):

    Convert persistent data to JSON-compatible values
    Validate data before writing
    Write data to a temporary file
    Replace the previous save with the new file
    Display save confirmation
```

**Load:**

```text
FUNCTION load_game():

    Check whether save file exists

    IF file does not exist:
        Offer a new game

    ELSE:
        Read JSON file
        Parse saved data
        Validate required fields and values
        Reconstruct player and game state

        IF save data is invalid:
            Display a useful error message
            Offer recovery or a new game
        ELSE:
            Resume saved game
        END IF

    END IF
```

Writing to a temporary file before replacing the previous save can reduce the risk of losing a valid save if writing is interrupted.

## 6. Overall Game Flowchart

```text
                 ┌───────────────┐
                 │     START     │
                 └───────┬───────┘
                         ▼
                 ┌───────────────┐
                 │   MAIN MENU   │
                 └───────┬───────┘
                         ▼
                 ┌───────────────┐
                 │ New Game /    │
                 │ Load Game?    │
                 └───────┬───────┘
                         ▼
                 ┌───────────────┐
                 │ Create or Load│
                 │   Character   │
                 └───────┬───────┘
                         ▼
                 ┌───────────────┐
                 │ Explore Region│
                 └───────┬───────┘
                         ▼
                 ┌───────────────┐
                 │ Enemy / Boss  │
                 │ Encounter     │
                 └───────┬───────┘
                         ▼
                 ┌───────────────┐
                 │ Combat Actions│
                 └───────┬───────┘
                         ▼
                 ┌───────────────┐
                 │ Update Health │
                 │ and Game State│
                 └───────┬───────┘
                         ▼
                 ┌───────────────┐
                 │ Battle Over?  │
                 └───┬───────┬───┘
                    No       Yes
                     │        │
                     │        ▼
                     │  ┌───────────────┐
                     │  │ Award Rewards │
                     │  │ Update Level  │
                     │  └───────┬───────┘
                     │          ▼
                     │  ┌───────────────┐
                     │  │ Progression   │
                     │  │ / Boss Check  │
                     │  └───────┬───────┘
                     │          ▼
                     │  ┌───────────────┐
                     │  │ Final Boss    │
                     │  │ Defeated?     │
                     │  └───────┬───────┘
                     │          ▼
                     │  ┌───────────────┐
                     │  │ Victory Screen│
                     │  └───────────────┘
                     │
                     └── Return to Combat

       Player HP = 0  → Game Over
       Save selected  → Write JSON save
       Exit selected  → End program
```

*This is a conceptual flowchart. The implementation must route player defeat, victory, escaping, and other combat outcomes to the appropriate branches.*

## 7. Input Validation and Error Handling

The game should validate user input before performing an operation.

Examples include:

- Rejecting menu selections outside the available range.
- Preventing the use of unavailable items.
- Preventing equipment actions on incompatible items.
- Rejecting purchases when the player lacks sufficient gold.
- Preventing skills from being used without enough mana.
- Handling missing, malformed, or incomplete JSON save files.
- Handling invalid numeric input without terminating the application unexpectedly.

Example validation pattern:

```python
while True:
    choice = input("Choose an option: ").strip()

    if choice.isdigit():
        choice = int(choice)

        if 1 <= choice <= 8:
            break

    print("Invalid choice. Please try again.")
```

## 8. Testing Strategy

Testing verifies that the game behaves correctly under normal and unusual conditions.

| Test Area | Example Test | Expected Result |
|---|---|---|
| Character creation | Select Mage | Mage statistics and skills are assigned |
| Combat | Attack an enemy | Health and damage are updated |
| Critical hit | Trigger a critical attack | Configured bonus damage is applied |
| Defend | Receive an eligible attack while defending | Incoming damage is reduced |
| Skills | Use a skill without enough mana | Action is rejected |
| Inventory | Equip an owned weapon | Equipment is updated |
| Shop | Purchase an item without enough gold | Purchase is rejected |
| Level progression | Earn enough XP | Level and configured statistics increase |
| Boss system | Reach Level 10 | Level-10 boss encounter is triggered |
| Save/load | Save and reload progress | Persistent data is restored |
| Invalid save | Load malformed JSON | Error is handled safely |
| Game over | Player health reaches zero | Game-over screen is displayed |
| Final victory | Defeat the final boss | Victory screen is displayed |

## 9. Expected Outcomes

The completed project is expected to provide:

- A playable command-line RPG.
- Four character classes with different gameplay styles.
- Turn-based combat and special abilities.
- Inventory, equipment, potions, and shop management.
- Multiple enemies, regions, and boss encounters.
- Character progression through Level 100.
- Randomized rewards and replayable encounters.
- Persistent progress through JSON save/load.
- Input validation and error handling.
- Clear victory and game-over outcomes.

## 10. Conclusion

**Legends of the Forgotten Realm** demonstrates how Python can be used to build a modular, interactive role-playing game. By combining object-oriented programming, turn-based combat, randomized events, character progression, inventory management, and JSON persistence, the project provides practical experience in software design and game development.

Its modular architecture also makes future expansion possible, including additional character classes, new regions, more enemies, quest systems, dialogue, crafting, and advanced combat mechanics.

The final implementation should ensure that all documented features are connected to working code and that combat, progression, save/load, and victory conditions are tested before release.
