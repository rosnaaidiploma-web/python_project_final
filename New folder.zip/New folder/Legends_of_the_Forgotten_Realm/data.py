from models import Weapon, Armor, Potion, Enemy

RANKS = {
    "Common": 1.0, "Uncommon": 1.1, "Rare": 1.3,
    "Super Rare": 1.5, "Epic": 1.8, "Mythical": 2.2, "Legendary": 2.8
}
CRIT_BONUS = {
    "Common": 0.00, "Uncommon": 0.02, "Rare": 0.05,
    "Super Rare": 0.08, "Epic": 0.12, "Mythical": 0.18, "Legendary": 0.25
}
DROP_CHANCES = [
    ("Common", .50), ("Uncommon", .25), ("Rare", .15),
    ("Super Rare", .06), ("Epic", .03), ("Mythical", .009), ("Legendary", .001)
]

REGIONS = ["Village","Forest","Cave","Desert","Ruins","Castle","Volcano","Frozen Mountain","Sky Temple","Demon Realm"]

BOSS_NAMES = {
    10:"Goblin King", 20:"Forest Guardian", 30:"Ancient Golem", 40:"Vampire Lord",
    50:"Dragon Rider", 60:"Demon General", 70:"Ice Titan", 80:"Shadow Emperor",
    90:"Celestial Dragon", 100:"Ancient Demon King"
}

CLASS_DATA = {
    "Warrior": {"hp":140,"mana":45,"attack":22,"defense":14,"crit":.06,
                "skills":[("Slash",5,1.25),("Shield Bash",8,1.15),("Rage",12,1.55),("Earthquake",20,2.1)]},
    "Mage": {"hp":95,"mana":110,"attack":18,"defense":7,"crit":.10,
             "skills":[("Fireball",7,1.55),("Ice Blast",10,1.75),("Thunder Strike",15,2.0),("Meteor",25,2.8)]},
    "Archer": {"hp":105,"mana":70,"attack":19,"defense":10,"crit":.15,
               "skills":[("Multi Shot",6,1.35),("Poison Arrow",9,1.6),("Explosive Arrow",15,2.0),("Sniper Shot",22,2.7)]},
    "Assassin": {"hp":85,"mana":75,"attack":24,"defense":6,"crit":.22,
                 "skills":[("Backstab",6,1.5),("Smoke Bomb",10,1.3),("Shadow Strike",15,2.1),("Instant Kill",30,4.5)]},
}

WEAPONS = []
_weapon_names = [
("Wooden Sword","Common",5,1),("Rusty Axe","Common",7,1),("Training Bow","Common",6,1),
("Apprentice Wand","Common",6,1),("Iron Sword","Rare",14,5),("Steel Axe","Rare",16,7),
("Long Bow","Rare",13,5),("Moon Staff","Rare",12,6),("Crystal Blade","Super Rare",21,10),
("Shadow Dagger","Super Rare",23,12),("Lightning Bow","Super Rare",20,10),("Flame Sword","Epic",29,15),
("Ice Spear","Epic",28,16),("Thunder Hammer","Epic",31,18),("Phoenix Blade","Mythical",39,22),
("Demon Slayer","Mythical",42,25),("Celestial Staff","Mythical",40,24),("Dragon King's Sword","Legendary",55,35),
("Blade of Eternity","Legendary",58,38),("Bow of the Gods","Legendary",54,36)
]
for name, rank, dmg, req in _weapon_names:
    mult = RANKS[rank]
    WEAPONS.append(Weapon(name, rank, int(dmg*mult), CRIT_BONUS[rank], int(dmg*mult*12), req))

ARMOR = []
_armor_names = [
("Cloth Armor","Common",2,0,5,0,1),("Leather Set","Common",4,10,0,0.01,1),
("Iron Guard","Rare",8,20,0,.02,5),("Hunter Mail","Rare",7,10,10,.03,5),
("Crystal Armor","Super Rare",12,35,15,.05,10),("Shadow Suit","Super Rare",10,20,25,.07,12),
("Flame Plate","Epic",18,50,10,.08,20),("Ice Guardian","Epic",17,40,25,.10,20),
("Thunder Armor","Epic",20,35,20,.10,22),("Phoenix Armor","Mythical",27,80,30,.14,30),
("Demon Lord Armor","Mythical",30,70,45,.16,35),("Eternal Aegis","Legendary",40,120,60,.22,50)
]
for name, rank, defense, hp, mana, resist, req in _armor_names:
    ARMOR.append(Armor(name,rank,defense,hp,mana,resist,defense*50,req))

POTIONS = [
Potion("Small Health Potion","health",hp=50,price=25),
Potion("Medium Health Potion","health",hp=100,price=50),
Potion("Large Health Potion","health",hp=250,price=100),
Potion("Giant Health Potion","health",hp=500,price=180),
Potion("Ultimate Health Potion","health",hp=-1,price=300),
Potion("Small Mana Potion","mana",mana=30,price=30),
Potion("Medium Mana Potion","mana",mana=75,price=60),
Potion("Large Mana Potion","mana",mana=150,price=120),
Potion("Giant Mana Potion","mana",mana=300,price=220),
Potion("Ultimate Mana Potion","mana",mana=-1,price=350),
Potion("Elixir","mixed",hp=120,mana=80,price=130),
Potion("Mega Elixir","mixed",hp=300,mana=200,price=280),
Potion("Strength Tonic","buff",attack=12,turns=3,price=100),
Potion("Guardian Tonic","buff",defense=10,turns=3,price=100),
Potion("Focus Tonic","buff",crit=.12,turns=3,price=120),
]

ENEMY_NAMES = [
("Goblin",1),("Wolf",2),("Slime",3),("Zombie",5),("Skeleton",7),
("Orc",11),("Bandit",13),("Troll",15),("Dark Archer",18),("Giant Spider",20),
("Vampire",21),("Werewolf",23),("Necromancer",25),("Ice Golem",28),("Fire Demon",30),
("Sand Wyrm",32),("Desert Raider",35),("Ancient Mummy",38),("Ruins Knight",40),("Castle Wraith",45),
("Dark Knight",50),("Lava Beast",55),("Inferno Demon",60),("Frost Giant",65),("Sky Serpent",70),
("Temple Guardian",75),("Void Mage",80),("Demon Hound",85),("Abyss Knight",92),("Realm Destroyer",98)
]

def make_enemy(name, level):
    scale = 1 + level * .11
    hp = int(65 * scale + level * 7)
    attack = int(10 * scale + level * 2)
    defense = int(5 * scale + level * .8)
    return Enemy(name, level, hp, attack, defense, int(35*scale), int(20*scale),
                 ["Strike","Heavy Blow"] if level % 2 else ["Strike","Drain"])

def boss_for(level):
    name = BOSS_NAMES[level]
    scale = 1 + level*.16
    return Enemy(name, level, int(450*scale), int(25*scale), int(12*scale),
                 int(350*scale), int(500*scale), ["Crushing Blow","Dark Magic","Heal"], True, 3)
