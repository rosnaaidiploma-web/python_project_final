import json, os, random, time
from models import Player
from data import CLASS_DATA, REGIONS, BOSS_NAMES, WEAPONS, ARMOR, POTIONS, ENEMY_NAMES, make_enemy, boss_for, DROP_CHANCES

SAVE_FILE = "savegame.json"

class Game:
    def __init__(self):
        self.player = None
        self.start_time = time.time()

    def clear(self):
        os.system("cls" if os.name == "nt" else "clear")

    def pause(self):
        input("\nPress Enter to continue...")

    def ask_int(self, prompt, low, high):
        while True:
            try:
                value = int(input(prompt))
                if low <= value <= high:
                    return value
                print(f"Enter a number from {low} to {high}.")
            except ValueError:
                print("Invalid input. Please enter a number.")

    def banner(self):
        self.clear()
        print("="*72)
        print("             LEGENDS OF THE FORGOTTEN REALM")
        print("                   A PYTHON TURN-BASED RPG")
        print("="*72)

    def run(self):
        while True:
            self.banner()
            print("1. New Game")
            print("2. Continue")
            print("3. Instructions")
            print("4. Exit")
            choice = self.ask_int("\nChoose: ",1,4)
            if choice == 1:
                self.new_game()
                self.main_loop()
            elif choice == 2:
                if self.load_game():
                    self.main_loop()
            elif choice == 3:
                self.instructions()
            else:
                print("Thanks for playing!")
                return

    def instructions(self):
        self.banner()
        print("""
OBJECTIVE
Defeat the bosses every 10 levels, unlock every region, reach Level 100,
and defeat the Ancient Demon King.

BATTLE
Attack, Skills, Heal, Use Potion, Defend, Inventory, Stats, Run.
Defend reduces the next incoming attack by 50%.

SAVE
Use Save Game from the world menu. Your progress is stored in savegame.json.

TIP
Buy better gear, manage mana, use buffs before boss fights, and watch your
level cap. Bosses are required before the next region can be unlocked.
""")
        self.pause()

    def new_game(self):
        self.banner()
        name = input("Enter Player Name: ").strip() or "Hero"
        print("\nChoose Your Class")
        classes = list(CLASS_DATA)
        for i,c in enumerate(classes,1):
            d = CLASS_DATA[c]
            print(f"{i}. {c} | HP {d['hp']} | Mana {d['mana']} | ATK {d['attack']} | DEF {d['defense']} | Crit {d['crit']*100:.0f}%")
        c = classes[self.ask_int("Class: ",1,len(classes))-1]
        d = CLASS_DATA[c]
        self.player = Player(name,c,max_hp=d["hp"],hp=d["hp"],max_mana=d["mana"],mana=d["mana"],
                             attack=d["attack"],defense=d["defense"],crit=d["crit"])
        self.player.inventory_weapons = [WEAPONS[0].__dict__]
        self.player.inventory_armor = [ARMOR[0].__dict__]
        self.player.potions = {"Small Health Potion":3,"Small Mana Potion":2}
        self.player.materials = {"Monster Essence":0}
        self.player.unlocked_skills = [d["skills"][0][0]]
        self.start_time = time.time()
        print(f"\nWelcome, {name} the {c}!")
        self.pause()

    def save_game(self):
        if not self.player: return
        with open(SAVE_FILE,"w",encoding="utf-8") as f:
            json.dump(self.player.__dict__, f, indent=2)
        print("Game saved successfully.")

    def load_game(self):
        if not os.path.exists(SAVE_FILE):
            print("No savegame.json found.")
            self.pause()
            return False
        try:
            with open(SAVE_FILE,"r",encoding="utf-8") as f:
                d=json.load(f)
            self.player=Player(**d)
            print(f"Loaded {self.player.name}, Level {self.player.level}.")
            self.pause()
            return True
        except (OSError, json.JSONDecodeError, TypeError) as e:
            print("Could not load save:", e)
            self.pause()
            return False

    def main_loop(self):
        while self.player:
            self.banner()
            p=self.player
            print(f"{p.name} | {p.class_name} | Level {p.level} | EXP {p.exp} | Gold {p.gold}")
            print(f"HP {p.hp}/{p.max_hp} | Mana {p.mana}/{p.max_mana} | Region: {REGIONS[p.region_index]}")
            print("\n1. Explore")
            print("2. Character Stats")
            print("3. Inventory")
            print("4. Shop")
            print("5. World Map")
            print("6. Save Game")
            print("7. Quit to Main Menu")
            ch=self.ask_int("Choose: ",1,7)
            if ch==1: self.explore()
            elif ch==2: self.stats()
            elif ch==3: self.inventory_menu()
            elif ch==4: self.shop()
            elif ch==5: self.world_map()
            elif ch==6: self.save_game(); self.pause()
            else: return

    def stats(self):
        p=self.player; self.banner()
        print(f"NAME: {p.name}\nCLASS: {p.class_name}\nLEVEL: {p.level}\nEXP: {p.exp}/{self.exp_needed()}")
        print(f"HP: {p.hp}/{p.max_hp}\nMANA: {p.mana}/{p.max_mana}")
        print(f"ATTACK: {p.effective_attack()}\nDEFENSE: {p.effective_defense()}")
        print(f"CRIT: {p.effective_crit()*100:.1f}%\nCRIT DAMAGE: {p.crit_damage:.2f}x")
        print(f"GOLD: {p.gold}\nEnemies Defeated: {p.enemies_defeated}\nBosses Defeated: {p.bosses_defeated}")
        print(f"Weapon: {p.weapon['name']} ({p.weapon['rank']})")
        print(f"Armor: {p.armor['name']} ({p.armor['rank']})")
        print("Skills:", ", ".join(p.unlocked_skills))
        self.pause()

    def exp_needed(self):
        return 100 + (self.player.level-1)*80

    def gain_exp(self, amount):
        p=self.player; p.exp += amount
        while p.level < 100 and p.exp >= self.exp_needed():
            p.exp -= self.exp_needed()
            p.level += 1
            p.max_hp += 12; p.max_mana += 7; p.attack += 3; p.defense += 2
            p.hp=p.max_hp; p.mana=p.max_mana
            print(f"\nLEVEL UP! You reached Level {p.level}.")
            if p.level % 5 == 0:
                idx=min(3,p.level//5-1)
                skills=CLASS_DATA[p.class_name]["skills"]
                skill=skills[idx][0]
                if skill not in p.unlocked_skills:
                    p.unlocked_skills.append(skill)
                    print(f"New skill unlocked: {skill}")
            if p.level % 10 == 0 and p.level < 100:
                print(f"Boss gate reached: {BOSS_NAMES[p.level]} must be defeated.")

    def explore(self):
        p=self.player
        if p.level % 10 == 0 and p.bosses_defeated < p.level//10:
            print(f"\nThe path is blocked by {BOSS_NAMES[p.level]}!")
            self.boss_battle()
            return
        max_level = min(100,p.level+3)
        candidates=[x for x in ENEMY_NAMES if abs(x[1]-p.level)<=8 and x[1]<=max_level]
        if not candidates: candidates=[ENEMY_NAMES[min(len(ENEMY_NAMES)-1,max(0,p.level//4))]]
        name,base=random.choice(candidates)
        enemy=make_enemy(name,max(1,p.level+random.randint(-2,2)))
        self.battle(enemy)

    def boss_battle(self):
        level=((self.player.level//10)*10)
        if level==0: level=10
        self.battle(boss_for(level),True)

    def battle(self, enemy, boss=False):
        p=self.player
        defending=False
        turn=0
        while enemy.hp>0 and p.hp>0:
            turn += 1
            self.clear()
            print("="*60)
            print(f"BATTLE: {p.name} Lv.{p.level} vs {enemy.name} Lv.{enemy.level}")
            print("="*60)
            print(f"YOU   HP {p.hp}/{p.max_hp}  MANA {p.mana}/{p.max_mana}")
            print(f"ENEMY HP {enemy.hp}/{enemy.hp}  ATK {enemy.attack} DEF {enemy.defense}")
            print("\n1 Attack\n2 Skills\n3 Heal\n4 Use Potion\n5 Defend\n6 Inventory\n7 View Stats\n8 Run")
            choice=self.ask_int("Action: ",1,8)
            if choice==1:
                self.attack_enemy(enemy)
            elif choice==2:
                if not self.use_skill(enemy): continue
            elif choice==3:
                heal=min(35,p.max_hp-p.hp)
                p.hp += heal
                print(f"You recover {heal} HP.")
            elif choice==4:
                if not self.potion_menu(in_battle=True): continue
            elif choice==5:
                defending=True
                print("You defend. Incoming damage is reduced by 50%.")
            elif choice==6:
                self.inventory_menu(in_battle=True); continue
            elif choice==7:
                self.stats(); continue
            else:
                if boss:
                    print("You cannot run from a boss!")
                    self.pause()
                    continue
                if random.random()<.5:
                    print("You escaped.")
                    self.pause()
                    return
                print("You failed to escape!")
            if enemy.hp<=0: break
            if turn % 3 == 0 and enemy.skills:
                dmg=max(1,int(enemy.attack*1.5)-p.effective_defense())
                if "Drain" in enemy.skills:
                    heal=min(enemy.hp,int(dmg*.5)); enemy.hp+=0; print(f"{enemy.name} uses Drain!")
                    p.hp-=int(dmg*.8); print(f"You take {int(dmg*.8)} damage.")
                elif "Heal" in enemy.skills and enemy.hp < int(enemy.hp):
                    pass
                else:
                    p.hp-=max(1,int(dmg*(.5 if defending else 1)))
                    print(f"{enemy.name} uses a special attack!")
            else:
                dmg=max(1,enemy.attack-p.effective_defense())
                if random.random()<.12:
                    dmg*=2; print(f"{enemy.name} lands a CRITICAL HIT!")
                if defending: dmg=max(1,dmg//2)
                p.hp-=dmg
                print(f"{enemy.name} deals {dmg} damage.")
            defending=False
            p.tick_buffs()
            if p.hp<=0:
                print("\nYou have fallen in battle.")
                self.game_over()
                return
            self.pause()
        if p.hp>0:
            self.victory(enemy,boss)

    def attack_enemy(self, enemy):
        p=self.player
        damage=max(1,p.effective_attack()-enemy.defense+random.randint(-3,5))
        critical=random.random()<p.effective_crit()
        if critical:
            damage=max(1,int(damage*p.crit_damage))
            print("CRITICAL HIT!")
        enemy.hp-=damage
        print(f"You deal {damage} damage.")

    def use_skill(self,enemy):
        skills=CLASS_DATA[self.player.class_name]["skills"]
        available=[s for s in skills if s[0] in self.player.unlocked_skills]
        if not available:
            print("No skills unlocked.")
            self.pause(); return False
        print("\nSkills:")
        for i,s in enumerate(available,1): print(f"{i}. {s[0]} - Mana {s[1]}")
        idx=self.ask_int("Skill: ",1,len(available))-1
        name,cost,mult=available[idx]
        if self.player.mana<cost:
            print("Not enough mana."); self.pause(); return False
        self.player.mana-=cost
        damage=max(1,int((self.player.effective_attack()-enemy.defense)*mult)+random.randint(0,6))
        if random.random()<self.player.effective_crit():
            damage=int(damage*self.player.crit_damage); print("CRITICAL SKILL!")
        enemy.hp-=damage
        print(f"{name} deals {damage} damage.")
        self.pause(); return True

    def potion_menu(self,in_battle=False):
        owned=[x for x,n in self.player.potions.items() if n>0]
        if not owned:
            print("No potions.")
            if in_battle:self.pause()
            return False
        print("\nPotions:")
        for i,name in enumerate(owned,1): print(f"{i}. {name} x{self.player.potions[name]}")
        idx=self.ask_int("Potion (0 cancel): ",0,len(owned))
        if idx==0:return False
        self.use_potion(owned[idx-1])
        self.pause()
        return True

    def use_potion(self,name):
        if self.player.potions.get(name,0)<=0:return
        potion=next(x for x in POTIONS if x.name==name)
        self.player.potions[name]-=1
        if potion.hp:
            self.player.hp=self.player.max_hp if potion.hp<0 else min(self.player.max_hp,self.player.hp+potion.hp)
        if potion.mana:
            self.player.mana=self.player.max_mana if potion.mana<0 else min(self.player.max_mana,self.player.mana+potion.mana)
        if potion.attack:self.player.active_buffs["attack"]={"value":potion.attack,"turns":potion.turns}
        if potion.defense:self.player.active_buffs["defense"]={"value":potion.defense,"turns":potion.turns}
        if potion.crit:self.player.active_buffs["crit"]={"value":potion.crit,"turns":potion.turns}
        print(f"Used {name}.")

    def victory(self,enemy,boss):
        p=self.player
        p.enemies_defeated+=1
        p.gold+=enemy.gold
        self.gain_exp(enemy.exp)
        print(f"\nVICTORY! {enemy.name} defeated.")
        print(f"+{enemy.exp} EXP   +{enemy.gold} Gold")
        p.materials["Monster Essence"]=p.materials.get("Monster Essence",0)+1
        self.loot(enemy,boss)
        if boss:
            p.bosses_defeated+=1
            p.region_index=min(9,p.bosses_defeated)
            print(f"\nBOSS DEFEATED! New region unlocked: {REGIONS[p.region_index]}")
            if enemy.level==100:
                self.victory_screen()
                return
        self.pause()

    def loot(self,enemy,boss):
        roll=random.random()
        if boss: roll=0
        cumulative=0
        rank="Common"
        for r,ch in DROP_CHANCES:
            cumulative+=ch
            if roll<=cumulative: rank=r; break
        eligible=[w for w in WEAPONS if w.rank==rank and w.required_level<=self.player.level]
        if eligible and (boss or random.random()<.35):
            w=random.choice(eligible).__dict__.copy()
            self.player.inventory_weapons.append(w); print(f"Loot: {w['rank']} weapon - {w['name']}")
            return
        eligible=[a for a in ARMOR if a.rank==rank and a.required_level<=self.player.level]
        if eligible and random.random()<.3:
            a=random.choice(eligible).__dict__.copy()
            self.player.inventory_armor.append(a); print(f"Loot: {a['rank']} armor - {a['name']}")
            return
        potion=random.choice(POTIONS)
        self.player.potions[potion.name]=self.player.potions.get(potion.name,0)+1
        print(f"Loot: {potion.name}")

    def inventory_menu(self,in_battle=False):
        while True:
            self.banner()
            print("1. Weapons\n2. Armor\n3. Potions\n4. Materials\n5. Back")
            ch=self.ask_int("Choose: ",1,5)
            if ch==1:
                for i,w in enumerate(self.player.inventory_weapons,1): print(f"{i}. {w['name']} [{w['rank']}] DMG {w['damage']} ReqLv {w['required_level']}")
                if self.player.inventory_weapons:
                    x=self.ask_int("Equip number (0 cancel): ",0,len(self.player.inventory_weapons))
                    if x:self.equip_weapon(self.player.inventory_weapons[x-1])
            elif ch==2:
                for i,a in enumerate(self.player.inventory_armor,1): print(f"{i}. {a['name']} [{a['rank']}] DEF {a['defense']} HP+{a['hp_bonus']} ReqLv {a['required_level']}")
                if self.player.inventory_armor:
                    x=self.ask_int("Equip number (0 cancel): ",0,len(self.player.inventory_armor))
                    if x:self.equip_armor(self.player.inventory_armor[x-1])
            elif ch==3:self.potion_menu(in_battle)
            elif ch==4:print("Materials:",self.player.materials);self.pause()
            else:return

    def equip_weapon(self,w):
        if self.player.level<w["required_level"]:print("Required level not reached.")
        else:self.player.weapon=w.copy();print(f"Equipped {w['name']}.")
        self.pause()

    def equip_armor(self,a):
        if self.player.level<a["required_level"]:print("Required level not reached.")
        else:
            old_bonus=self.player.armor.get("hp_bonus",0)+self.player.armor.get("mana_bonus",0)
            self.player.armor=a.copy()
            self.player.max_hp += a.get("hp_bonus",0)
            self.player.max_mana += a.get("mana_bonus",0)
            self.player.hp=min(self.player.hp,self.player.max_hp); self.player.mana=min(self.player.mana,self.player.max_mana)
            print(f"Equipped {a['name']}.")
        self.pause()

    def shop(self):
        while True:
            self.banner()
            print(f"Gold: {self.player.gold}")
            print("1. Buy Weapon\n2. Buy Armor\n3. Buy Potion\n4. Sell Items\n5. Exit")
            ch=self.ask_int("Choose: ",1,5)
            if ch==1:self.buy_weapon()
            elif ch==2:self.buy_armor()
            elif ch==3:self.buy_potion()
            elif ch==4:self.sell_items()
            else:return

    def buy_weapon(self):
        items=[w for w in WEAPONS if w.required_level<=self.player.level]
        for i,w in enumerate(items,1):print(f"{i}. {w.name} [{w.rank}] {w.price}g")
        x=self.ask_int("Buy (0 cancel): ",0,len(items))
        if x:
            w=items[x-1]
            if self.player.gold>=w.price:self.player.gold-=w.price;self.player.inventory_weapons.append(w.__dict__);print("Purchased.")
            else:print("Not enough gold.")
            self.pause()

    def buy_armor(self):
        items=[a for a in ARMOR if a.required_level<=self.player.level]
        for i,a in enumerate(items,1):print(f"{i}. {a.name} [{a.rank}] {a.price}g")
        x=self.ask_int("Buy (0 cancel): ",0,len(items))
        if x:
            a=items[x-1]
            if self.player.gold>=a.price:self.player.gold-=a.price;self.player.inventory_armor.append(a.__dict__);print("Purchased.")
            else:print("Not enough gold.")
            self.pause()

    def buy_potion(self):
        for i,p in enumerate(POTIONS,1):print(f"{i}. {p.name} - {p.price}g")
        x=self.ask_int("Buy (0 cancel): ",0,len(POTIONS))
        if x:
            p=POTIONS[x-1]
            if self.player.gold>=p.price:self.player.gold-=p.price;self.player.potions[p.name]=self.player.potions.get(p.name,0)+1;print("Purchased.")
            else:print("Not enough gold.")
            self.pause()

    def sell_items(self):
        print("1. Weapons  2. Armor  3. Back")
        ch=self.ask_int("Choose: ",1,3)
        if ch==1:
            items=self.player.inventory_weapons
        elif ch==2:items=self.player.inventory_armor
        else:return
        for i,x in enumerate(items,1):print(f"{i}. {x['name']} - Sell {max(1,x['price']//2)}g")
        if not items:return
        n=self.ask_int("Sell (0 cancel): ",0,len(items))
        if n:
            item=items[n-1]
            if item["name"]==self.player.weapon["name"]:print("Cannot sell equipped weapon.");self.pause();return
            self.player.gold+=max(1,item["price"]//2);items.pop(n-1);print("Sold.");self.pause()

    def world_map(self):
        self.banner()
        print("WORLD MAP")
        for i,r in enumerate(REGIONS):
            status="UNLOCKED" if i<=self.player.region_index else "LOCKED"
            print(f"{i+1:2}. {r:18} [{status}]")
        print("\nVillage → Forest → Cave → Desert → Ruins → Castle → Volcano →")
        print("Frozen Mountain → Sky Temple → Demon Realm")
        self.pause()

    def game_over(self):
        while True:
            self.banner()
            print("GAME OVER")
            print("1. Retry")
            print("2. Load Save")
            print("3. Exit")
            ch=self.ask_int("Choose: ",1,3)
            if ch==1:
                self.player.hp=self.player.max_hp; self.player.mana=self.player.max_mana
                self.pause(); return
            if ch==2:
                if self.load_game(): return
            else:
                self.player=None; return

    def victory_screen(self):
        p=self.player
        elapsed=int(time.time()-self.start_time)
        self.banner()
        print("                VICTORY!")
        print("        THE ANCIENT DEMON KING FALLS")
        print("-"*72)
        print(f"Player Name       : {p.name}")
        print(f"Final Level       : {p.level}")
        print(f"Total Gold        : {p.gold}")
        print(f"Bosses Defeated   : {p.bosses_defeated}")
        print(f"Enemies Defeated  : {p.enemies_defeated}")
        print(f"Weapons Collected : {len(p.inventory_weapons)}")
        print(f"Rare Items Found  : {sum(1 for w in p.inventory_weapons if w['rank'] not in ('Common','Uncommon'))}")
        print(f"Play Time         : {elapsed//60}m {elapsed%60}s")
        print(f"Final Score       : {p.level*100 + p.bosses_defeated*1000 + p.enemies_defeated*20 + p.gold}")
        print("-"*72)
        self.pause()
        self.player=None
