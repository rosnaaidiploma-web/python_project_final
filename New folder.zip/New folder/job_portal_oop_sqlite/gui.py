import tkinter as tk
from tkinter import ttk, messagebox

from database import Database
from models import User, Company, Job
from services import UserService, JobSeekerService, RecruiterService, AdminService


class JobPortalApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Job Portal Database System")
        self.root.geometry("1000x700")
        self.root.minsize(900, 600)

        self.db = Database()
        self.user_service = UserService(self.db)
        self.seeker_service = JobSeekerService(self.db)
        self.recruiter_service = RecruiterService(self.db)
        self.admin_service = AdminService(self.db)

        self.current_user = None
        self.current_user_type = None

        self.show_home()

    def clear(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def title(self, text):
        tk.Label(self.root, text=text, font=("Arial", 22, "bold")).pack(pady=15)

    def run(self):
        self.root.mainloop()

    # ---------------- HOME ----------------
    def show_home(self):
        self.clear()
        self.title("JOB PORTAL DATABASE SYSTEM")

        tk.Label(
            self.root,
            text="Python OOP + SQLite3",
            font=("Arial", 13)
        ).pack(pady=5)

        frame = tk.Frame(self.root)
        frame.pack(pady=40)

        tk.Button(frame, text="Login", width=20, height=2,
                  command=self.login_page).grid(row=0, column=0, padx=10, pady=10)
        tk.Button(frame, text="Register", width=20, height=2,
                  command=self.register_page).grid(row=0, column=1, padx=10, pady=10)
        tk.Button(frame, text="View Jobs", width=20, height=2,
                  command=self.public_jobs).grid(row=1, column=0, padx=10, pady=10)
        tk.Button(frame, text="Exit", width=20, height=2,
                  command=self.root.destroy).grid(row=1, column=1, padx=10, pady=10)

        tk.Label(
            self.root,
            text="Demo Admin: admin@gmail.com / admin123",
            font=("Arial", 10)
        ).pack(pady=30)

    # ---------------- LOGIN ----------------
    def login_page(self):
        self.clear()
        self.title("Login")

        form = tk.Frame(self.root)
        form.pack(pady=20)

        tk.Label(form, text="Email").grid(row=0, column=0, sticky="w", pady=8)
        email = tk.Entry(form, width=35)
        email.grid(row=0, column=1, pady=8)

        tk.Label(form, text="Password").grid(row=1, column=0, sticky="w", pady=8)
        password = tk.Entry(form, show="*", width=35)
        password.grid(row=1, column=1, pady=8)

        tk.Label(form, text="User Type").grid(row=2, column=0, sticky="w", pady=8)
        user_type = ttk.Combobox(
            form,
            values=["Job Seeker", "Recruiter", "Admin"],
            state="readonly",
            width=32
        )
        user_type.grid(row=2, column=1, pady=8)
        user_type.set("Job Seeker")

        def do_login():
            result = self.user_service.login(
                email.get().strip(),
                password.get(),
                user_type.get()
            )
            if not result:
                messagebox.showerror("Login", "Invalid login details.")
                return

            self.current_user = result
            self.current_user_type = result[4]

            if self.current_user_type == "Job Seeker":
                self.seeker_dashboard()
            elif self.current_user_type == "Recruiter":
                self.recruiter_dashboard()
            else:
                self.admin_dashboard()

        tk.Button(form, text="Login", width=18,
                  command=do_login).grid(row=3, column=1, pady=15)
        tk.Button(form, text="Back",
                  command=self.show_home).grid(row=4, column=1)

    # ---------------- REGISTER ----------------
    def register_page(self):
        self.clear()
        self.title("Create Account")

        form = tk.Frame(self.root)
        form.pack(pady=10)

        labels = ["Name", "Email", "Password", "Phone", "User Type"]
        entries = {}

        for i, label in enumerate(labels):
            tk.Label(form, text=label).grid(row=i, column=0, sticky="w", pady=6)
            if label == "User Type":
                widget = ttk.Combobox(
                    form,
                    values=["Job Seeker", "Recruiter"],
                    state="readonly",
                    width=32
                )
                widget.set("Job Seeker")
            else:
                widget = tk.Entry(form, width=35)
                if label == "Password":
                    widget.config(show="*")
            widget.grid(row=i, column=1, pady=6)
            entries[label] = widget

        def register():
            if not entries["Name"].get().strip() or not entries["Email"].get().strip():
                messagebox.showwarning("Register", "Name and email are required.")
                return

            user = User(
                entries["Name"].get().strip(),
                entries["Email"].get().strip(),
                entries["Password"].get(),
                entries["Phone"].get().strip(),
                entries["User Type"].get()
            )

            try:
                self.user_service.register(user)
                messagebox.showinfo("Register", "Account created successfully.")
                self.login_page()
            except ValueError as e:
                messagebox.showerror("Register", str(e))

        tk.Button(form, text="Register", width=18,
                  command=register).grid(row=5, column=1, pady=15)
        tk.Button(form, text="Back",
                  command=self.show_home).grid(row=6, column=1)

    # ---------------- PUBLIC JOBS ----------------
    def public_jobs(self):
        self.clear()
        self.title("Available Jobs")

        top = tk.Frame(self.root)
        top.pack(fill="x", padx=20)

        tk.Label(top, text="Search").pack(side="left")
        search = tk.Entry(top, width=40)
        search.pack(side="left", padx=8)

        columns = ("ID", "Job", "Company", "Location", "Salary", "Type", "Deadline")
        tree = ttk.Treeview(self.root, columns=columns, show="headings")
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=120)
        tree.pack(fill="both", expand=True, padx=20, pady=15)

        def load():
            for item in tree.get_children():
                tree.delete(item)
            rows = self.seeker_service.list_jobs(search.get().strip())
            for row in rows:
                tree.insert("", "end", values=row[:7])

        tk.Button(top, text="Search", command=load).pack(side="left")
        tk.Button(top, text="Back", command=self.show_home).pack(side="right")
        load()

    # ---------------- SEEKER DASHBOARD ----------------
    def seeker_dashboard(self):
        self.clear()
        self.title(f"Job Seeker Dashboard - {self.current_user[1]}")

        buttons = [
            ("My Profile", self.seeker_profile),
            ("Search Jobs", self.seeker_jobs),
            ("My Applications", self.seeker_applications),
            ("Logout", self.logout)
        ]
        for text, command in buttons:
            tk.Button(self.root, text=text, width=25, height=2,
                      command=command).pack(pady=7)

    def seeker_profile(self):
        self.clear()
        self.title("Job Seeker Profile")

        seeker_id = self.current_user[0]
        old = self.seeker_service.get_profile(seeker_id)

        labels = [
            "Qualification", "Skills", "Experience",
            "Resume", "Preferred Location"
        ]
        entries = {}

        form = tk.Frame(self.root)
        form.pack(pady=10)

        for i, label in enumerate(labels):
            tk.Label(form, text=label).grid(row=i, column=0, sticky="w", pady=6)
            entry = tk.Entry(form, width=55)
            entry.grid(row=i, column=1, pady=6)
            entries[label] = entry

        if old:
            values = old[3:]
            for label, value in zip(labels, values):
                entries[label].insert(0, value or "")

        def save():
            self.seeker_service.update_profile(
                seeker_id,
                entries["Qualification"].get(),
                entries["Skills"].get(),
                entries["Experience"].get(),
                entries["Resume"].get(),
                entries["Preferred Location"].get()
            )
            messagebox.showinfo("Profile", "Profile updated.")
            self.seeker_dashboard()

        tk.Button(form, text="Save Profile", command=save).grid(
            row=5, column=1, pady=15
        )
        tk.Button(form, text="Back",
                  command=self.seeker_dashboard).grid(row=6, column=1)

    def seeker_jobs(self):
        self.clear()
        self.title("Search and Apply for Jobs")

        top = tk.Frame(self.root)
        top.pack(fill="x", padx=20)

        tk.Label(top, text="Keyword").pack(side="left")
        search = tk.Entry(top, width=35)
        search.pack(side="left", padx=8)

        columns = ("ID", "Job", "Company", "Location", "Salary", "Type", "Deadline")
        tree = ttk.Treeview(self.root, columns=columns, show="headings")
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=120)
        tree.pack(fill="both", expand=True, padx=20, pady=10)

        def load():
            for item in tree.get_children():
                tree.delete(item)
            for row in self.seeker_service.list_jobs(search.get().strip()):
                tree.insert("", "end", values=row[:7])

        def apply():
            selected = tree.selection()
            if not selected:
                messagebox.showwarning("Apply", "Select a job first.")
                return
            job_id = tree.item(selected[0])["values"][0]
            ok = self.seeker_service.apply(job_id, self.current_user[0])
            if ok:
                messagebox.showinfo("Apply", "Application submitted.")
            else:
                messagebox.showwarning(
                    "Apply", "You may have already applied for this job."
                )

        tk.Button(top, text="Search", command=load).pack(side="left")
        tk.Button(top, text="Apply", command=apply).pack(side="left", padx=5)
        tk.Button(top, text="Back",
                  command=self.seeker_dashboard).pack(side="right")
        load()

    def seeker_applications(self):
        self.clear()
        self.title("My Applications")

        columns = ("ID", "Job", "Company", "Date", "Status")
        tree = ttk.Treeview(self.root, columns=columns, show="headings")
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=160)
        tree.pack(fill="both", expand=True, padx=20, pady=20)

        for row in self.seeker_service.applications(self.current_user[0]):
            tree.insert("", "end", values=row)

        tk.Button(self.root, text="Back",
                  command=self.seeker_dashboard).pack(pady=10)

    # ---------------- RECRUITER DASHBOARD ----------------
    def recruiter_dashboard(self):
        self.clear()
        self.title(f"Recruiter Dashboard - {self.current_user[1]}")

        buttons = [
            ("Create Company", self.create_company),
            ("Post Job", self.post_job),
            ("My Jobs", self.recruiter_jobs),
            ("View Applications", self.recruiter_applications),
            ("Logout", self.logout)
        ]
        for text, command in buttons:
            tk.Button(self.root, text=text, width=25, height=2,
                      command=command).pack(pady=6)

    def create_company(self):
        self.clear()
        self.title("Create Company")

        labels = ["Company Name", "Industry", "Location", "Description"]
        entries = {}
        form = tk.Frame(self.root)
        form.pack(pady=20)

        for i, label in enumerate(labels):
            tk.Label(form, text=label).grid(row=i, column=0, sticky="w", pady=7)
            entry = tk.Entry(form, width=55)
            entry.grid(row=i, column=1, pady=7)
            entries[label] = entry

        def save():
            if not entries["Company Name"].get().strip():
                messagebox.showwarning("Company", "Company name is required.")
                return
            company = Company(
                self.current_user[0],
                entries["Company Name"].get(),
                entries["Industry"].get(),
                entries["Location"].get(),
                entries["Description"].get()
            )
            self.recruiter_service.create_company(company)
            messagebox.showinfo("Company", "Company created.")
            self.recruiter_dashboard()

        tk.Button(form, text="Save", command=save).grid(row=4, column=1, pady=15)
        tk.Button(form, text="Back",
                  command=self.recruiter_dashboard).grid(row=5, column=1)

    def post_job(self):
        companies = self.recruiter_service.companies(self.current_user[0])
        if not companies:
            messagebox.showwarning(
                "Post Job", "Create a company before posting a job."
            )
            return

        self.clear()
        self.title("Post New Job")

        form = tk.Frame(self.root)
        form.pack(pady=10)

        tk.Label(form, text="Company").grid(row=0, column=0, sticky="w", pady=6)
        company_box = ttk.Combobox(
            form,
            values=[f"{r[0]} - {r[1]}" for r in companies],
            state="readonly",
            width=45
        )
        company_box.grid(row=0, column=1, pady=6)
        company_box.current(0)

        labels = [
            "Job Title", "Description", "Skills", "Qualification",
            "Location", "Salary", "Job Type", "Deadline"
        ]
        entries = {}

        for i, label in enumerate(labels, start=1):
            tk.Label(form, text=label).grid(row=i, column=0, sticky="w", pady=5)
            entry = tk.Entry(form, width=55)
            entry.grid(row=i, column=1, pady=5)
            entries[label] = entry

        def save():
            company_id = int(company_box.get().split(" - ")[0])
            job = Job(
                company_id,
                entries["Job Title"].get(),
                entries["Description"].get(),
                entries["Skills"].get(),
                entries["Qualification"].get(),
                entries["Location"].get(),
                entries["Salary"].get(),
                entries["Job Type"].get(),
                entries["Deadline"].get()
            )
            self.recruiter_service.post_job(job)
            messagebox.showinfo("Job", "Job posted successfully.")
            self.recruiter_dashboard()

        tk.Button(form, text="Post Job", command=save).grid(
            row=9, column=1, pady=15
        )
        tk.Button(form, text="Back",
                  command=self.recruiter_dashboard).grid(row=10, column=1)

    def recruiter_jobs(self):
        self.clear()
        self.title("My Job Postings")

        columns = ("ID", "Job", "Company", "Location", "Salary", "Type", "Deadline")
        tree = ttk.Treeview(self.root, columns=columns, show="headings")
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=125)
        tree.pack(fill="both", expand=True, padx=20, pady=20)

        for row in self.recruiter_service.my_jobs(self.current_user[0]):
            tree.insert("", "end", values=row)

        tk.Button(self.root, text="Back",
                  command=self.recruiter_dashboard).pack(pady=10)

    def recruiter_applications(self):
        self.clear()
        self.title("Candidate Applications")

        columns = ("ID", "Job", "Company", "Candidate", "Email", "Date", "Status")
        tree = ttk.Treeview(self.root, columns=columns, show="headings")
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=130)
        tree.pack(fill="both", expand=True, padx=10, pady=10)

        for row in self.recruiter_service.applications(self.current_user[0]):
            tree.insert("", "end", values=row)

        bottom = tk.Frame(self.root)
        bottom.pack(pady=10)

        status = ttk.Combobox(
            bottom,
            values=["Applied", "Under Review", "Shortlisted", "Rejected", "Selected"],
            state="readonly",
            width=18
        )
        status.set("Under Review")
        status.pack(side="left", padx=5)

        def update():
            selected = tree.selection()
            if not selected:
                messagebox.showwarning("Update", "Select an application.")
                return
            application_id = tree.item(selected[0])["values"][0]
            self.recruiter_service.update_application(
                application_id, status.get()
            )
            messagebox.showinfo("Update", "Application status updated.")
            self.recruiter_applications()

        tk.Button(bottom, text="Update Status", command=update).pack(side="left")
        tk.Button(bottom, text="Back",
                  command=self.recruiter_dashboard).pack(side="left", padx=5)

    # ---------------- ADMIN ----------------
    def admin_dashboard(self):
        self.clear()
        self.title("Admin Dashboard")

        counts = self.admin_service.dashboard()
        names = ["Total Users", "Job Seekers", "Recruiters", "Jobs", "Applications"]

        box = tk.Frame(self.root)
        box.pack(pady=20)

        for i, (name, count) in enumerate(zip(names, counts)):
            tk.Label(
                box,
                text=f"{name}: {count}",
                font=("Arial", 14)
            ).grid(row=i, column=0, sticky="w", pady=5)

        tk.Button(self.root, text="Manage Users", width=25,
                  command=self.admin_users).pack(pady=5)
        tk.Button(self.root, text="View Jobs", width=25,
                  command=self.admin_jobs).pack(pady=5)
        tk.Button(self.root, text="Refresh", width=25,
                  command=self.admin_dashboard).pack(pady=5)
        tk.Button(self.root, text="Logout", width=25,
                  command=self.logout).pack(pady=5)

    def admin_users(self):
        self.clear()
        self.title("Admin - User Management")

        columns = ("ID", "Name", "Email", "Phone", "Type")
        tree = ttk.Treeview(self.root, columns=columns, show="headings")
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=170)
        tree.pack(fill="both", expand=True, padx=20, pady=20)

        for row in self.admin_service.users():
            tree.insert("", "end", values=row)

        def delete():
            selected = tree.selection()
            if not selected:
                messagebox.showwarning("Delete", "Select a user.")
                return

            user_id = tree.item(selected[0])["values"][0]
            if user_id == 1:
                messagebox.showwarning("Delete", "Default admin cannot be deleted.")
                return

            if messagebox.askyesno("Delete", "Delete selected user?"):
                self.admin_service.delete_user(user_id)
                self.admin_users()

        tk.Button(self.root, text="Delete User",
                  command=delete).pack(side="left", padx=20, pady=10)
        tk.Button(self.root, text="Back",
                  command=self.admin_dashboard).pack(side="right", padx=20, pady=10)

    def admin_jobs(self):
        self.clear()
        self.title("Admin - Job Management")

        columns = ("ID", "Job", "Company", "Location", "Salary", "Type")
        tree = ttk.Treeview(self.root, columns=columns, show="headings")
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=150)
        tree.pack(fill="both", expand=True, padx=20, pady=20)

        for row in self.admin_service.jobs():
            tree.insert("", "end", values=row)

        tk.Button(self.root, text="Back",
                  command=self.admin_dashboard).pack(pady=10)

    def logout(self):
        self.current_user = None
        self.current_user_type = None
        self.show_home()
