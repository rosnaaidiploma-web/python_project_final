import sqlite3


class Database:
    def __init__(self, db_name="job_portal.db"):
        self.db_name = db_name
        self.create_tables()

    def connect(self):
        return sqlite3.connect(self.db_name)

    def create_tables(self):
        conn = self.connect()
        cur = conn.cursor()

        cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            phone TEXT,
            user_type TEXT NOT NULL CHECK(user_type IN ('Job Seeker','Recruiter','Admin'))
        )
        """)

        cur.execute("""
        CREATE TABLE IF NOT EXISTS job_seekers (
            seeker_id INTEGER PRIMARY KEY,
            qualification TEXT,
            skills TEXT,
            experience TEXT,
            resume TEXT,
            preferred_location TEXT,
            FOREIGN KEY (seeker_id) REFERENCES users(user_id)
        )
        """)

        cur.execute("""
        CREATE TABLE IF NOT EXISTS companies (
            company_id INTEGER PRIMARY KEY AUTOINCREMENT,
            recruiter_id INTEGER NOT NULL,
            company_name TEXT NOT NULL,
            industry TEXT,
            location TEXT,
            description TEXT,
            FOREIGN KEY (recruiter_id) REFERENCES users(user_id)
        )
        """)

        cur.execute("""
        CREATE TABLE IF NOT EXISTS jobs (
            job_id INTEGER PRIMARY KEY AUTOINCREMENT,
            company_id INTEGER NOT NULL,
            job_title TEXT NOT NULL,
            description TEXT,
            skills TEXT,
            qualification TEXT,
            location TEXT,
            salary TEXT,
            job_type TEXT,
            deadline TEXT,
            FOREIGN KEY (company_id) REFERENCES companies(company_id)
        )
        """)

        cur.execute("""
        CREATE TABLE IF NOT EXISTS applications (
            application_id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id INTEGER NOT NULL,
            seeker_id INTEGER NOT NULL,
            applied_date TEXT NOT NULL,
            status TEXT DEFAULT 'Applied',
            UNIQUE(job_id, seeker_id),
            FOREIGN KEY (job_id) REFERENCES jobs(job_id),
            FOREIGN KEY (seeker_id) REFERENCES job_seekers(seeker_id)
        )
        """)

        # Default admin account for demonstration.
        cur.execute("""
        INSERT OR IGNORE INTO users
        (user_id, name, email, password, phone, user_type)
        VALUES (1, 'Administrator', 'admin@gmail.com', 'admin123', '', 'Admin')
        """)

        conn.commit()
        conn.close()

    def execute(self, query, params=(), fetch=False, many=False):
        conn = self.connect()
        cur = conn.cursor()
        if many:
            cur.executemany(query, params)
        else:
            cur.execute(query, params)

        result = None
        if fetch:
            result = cur.fetchall()
        else:
            result = cur.lastrowid

        conn.commit()
        conn.close()
        return result
