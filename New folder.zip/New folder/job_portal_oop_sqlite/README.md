# Job Portal Database System

A beginner-friendly desktop Job Portal project using:

- Python
- OOP (Object-Oriented Programming)
- Tkinter
- SQLite3
- SQL CRUD operations

## Project structure

```text
job_portal_oop_sqlite/
│
├── main.py
├── gui.py
├── database.py
├── models.py
├── services.py
├── requirements.txt
└── README.md
```

## Run

Open PowerShell in this folder:

```powershell
python main.py
```

A file named `job_portal.db` will be created automatically.

## Default Admin

Email: `admin@gmail.com`

Password: `admin123`

Select User Type: `Admin`

## Main features

### Job Seeker
1. Register
2. Login
3. Create/update profile
4. Add qualification, skills and experience
5. Search jobs
6. Apply for jobs
7. View application status

### Recruiter
1. Register
2. Login
3. Create company
4. Post jobs
5. View job postings
6. View candidate applications
7. Change application status

### Admin
1. Login
2. View dashboard counts
3. View users
4. Delete users
5. View jobs

## Database tables

- users
- job_seekers
- companies
- jobs
- applications

## SQL operations demonstrated

- CREATE TABLE
- INSERT
- SELECT
- UPDATE
- DELETE
- WHERE
- LIKE
- JOIN
- ORDER BY
- COUNT
- PRIMARY KEY
- FOREIGN KEY
- UNIQUE
- CHECK
