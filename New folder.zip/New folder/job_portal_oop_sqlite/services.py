from datetime import date
from database import Database
from models import User, JobSeeker, Company, Job


class UserService:
    def __init__(self, db):
        self.db = db

    def register(self, user: User):
        try:
            user_id = self.db.execute("""
                INSERT INTO users(name, email, password, phone, user_type)
                VALUES (?, ?, ?, ?, ?)
            """, (user.name, user.email, user.password, user.phone, user.user_type))

            if user.user_type == "Job Seeker":
                self.db.execute("""
                    INSERT INTO job_seekers(seeker_id, qualification, skills,
                    experience, resume, preferred_location)
                    VALUES (?, '', '', '', '', '')
                """, (user_id,))

            return user_id
        except Exception as e:
            raise ValueError(f"Registration failed: {e}")

    def login(self, email, password, user_type):
        rows = self.db.execute("""
            SELECT user_id, name, email, phone, user_type
            FROM users
            WHERE email=? AND password=? AND user_type=?
        """, (email, password, user_type), fetch=True)
        return rows[0] if rows else None


class JobSeekerService:
    def __init__(self, db):
        self.db = db

    def get_profile(self, seeker_id):
        rows = self.db.execute("""
            SELECT u.name, u.email, u.phone,
                   j.qualification, j.skills, j.experience,
                   j.resume, j.preferred_location
            FROM users u
            JOIN job_seekers j ON u.user_id=j.seeker_id
            WHERE j.seeker_id=?
        """, (seeker_id,), fetch=True)
        return rows[0] if rows else None

    def update_profile(self, seeker_id, qualification, skills, experience,
                       resume, preferred_location):
        self.db.execute("""
            UPDATE job_seekers
            SET qualification=?, skills=?, experience=?,
                resume=?, preferred_location=?
            WHERE seeker_id=?
        """, (qualification, skills, experience, resume,
              preferred_location, seeker_id))

    def list_jobs(self, keyword=""):
        key = f"%{keyword}%"
        return self.db.execute("""
            SELECT j.job_id, j.job_title, c.company_name,
                   j.location, j.salary, j.job_type, j.deadline,
                   j.skills, j.qualification
            FROM jobs j
            JOIN companies c ON j.company_id=c.company_id
            WHERE j.job_title LIKE ?
               OR c.company_name LIKE ?
               OR j.location LIKE ?
               OR j.skills LIKE ?
            ORDER BY j.job_id DESC
        """, (key, key, key, key), fetch=True)

    def apply(self, job_id, seeker_id):
        try:
            self.db.execute("""
                INSERT INTO applications
                (job_id, seeker_id, applied_date, status)
                VALUES (?, ?, ?, 'Applied')
            """, (job_id, seeker_id, date.today().isoformat()))
            return True
        except Exception:
            return False

    def applications(self, seeker_id):
        return self.db.execute("""
            SELECT a.application_id, j.job_title, c.company_name,
                   a.applied_date, a.status
            FROM applications a
            JOIN jobs j ON a.job_id=j.job_id
            JOIN companies c ON j.company_id=c.company_id
            WHERE a.seeker_id=?
            ORDER BY a.application_id DESC
        """, (seeker_id,), fetch=True)


class RecruiterService:
    def __init__(self, db):
        self.db = db

    def create_company(self, company: Company):
        return self.db.execute("""
            INSERT INTO companies(recruiter_id, company_name, industry,
                                  location, description)
            VALUES (?, ?, ?, ?, ?)
        """, (company.recruiter_id, company.company_name, company.industry,
              company.location, company.description))

    def companies(self, recruiter_id):
        return self.db.execute("""
            SELECT company_id, company_name, industry, location, description
            FROM companies
            WHERE recruiter_id=?
        """, (recruiter_id,), fetch=True)

    def post_job(self, job: Job):
        return self.db.execute("""
            INSERT INTO jobs(company_id, job_title, description, skills,
                             qualification, location, salary, job_type, deadline)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (job.company_id, job.job_title, job.description, job.skills,
              job.qualification, job.location, job.salary, job.job_type,
              job.deadline))

    def my_jobs(self, recruiter_id):
        return self.db.execute("""
            SELECT j.job_id, j.job_title, c.company_name,
                   j.location, j.salary, j.job_type, j.deadline
            FROM jobs j
            JOIN companies c ON j.company_id=c.company_id
            WHERE c.recruiter_id=?
            ORDER BY j.job_id DESC
        """, (recruiter_id,), fetch=True)

    def applications(self, recruiter_id):
        return self.db.execute("""
            SELECT a.application_id, j.job_title, c.company_name,
                   u.name, u.email, a.applied_date, a.status
            FROM applications a
            JOIN jobs j ON a.job_id=j.job_id
            JOIN companies c ON j.company_id=c.company_id
            JOIN users u ON a.seeker_id=u.user_id
            WHERE c.recruiter_id=?
            ORDER BY a.application_id DESC
        """, (recruiter_id,), fetch=True)

    def update_application(self, application_id, status):
        self.db.execute("""
            UPDATE applications SET status=?
            WHERE application_id=?
        """, (status, application_id))


class AdminService:
    def __init__(self, db):
        self.db = db

    def dashboard(self):
        users = self.db.execute("SELECT COUNT(*) FROM users", fetch=True)[0][0]
        seekers = self.db.execute(
            "SELECT COUNT(*) FROM users WHERE user_type='Job Seeker'",
            fetch=True)[0][0]
        recruiters = self.db.execute(
            "SELECT COUNT(*) FROM users WHERE user_type='Recruiter'",
            fetch=True)[0][0]
        jobs = self.db.execute("SELECT COUNT(*) FROM jobs", fetch=True)[0][0]
        applications = self.db.execute(
            "SELECT COUNT(*) FROM applications", fetch=True)[0][0]
        return users, seekers, recruiters, jobs, applications

    def users(self):
        return self.db.execute("""
            SELECT user_id, name, email, phone, user_type
            FROM users ORDER BY user_id
        """, fetch=True)

    def delete_user(self, user_id):
        self.db.execute("DELETE FROM applications WHERE seeker_id=?", (user_id,))
        self.db.execute("DELETE FROM job_seekers WHERE seeker_id=?", (user_id,))

        companies = self.db.execute(
            "SELECT company_id FROM companies WHERE recruiter_id=?",
            (user_id,), fetch=True
        )
        for row in companies:
            self.db.execute("DELETE FROM applications WHERE job_id IN "
                            "(SELECT job_id FROM jobs WHERE company_id=?)",
                            (row[0],))
            self.db.execute("DELETE FROM jobs WHERE company_id=?", (row[0],))

        self.db.execute("DELETE FROM companies WHERE recruiter_id=?", (user_id,))
        self.db.execute("DELETE FROM users WHERE user_id=?", (user_id,))

    def jobs(self):
        return self.db.execute("""
            SELECT j.job_id, j.job_title, c.company_name,
                   j.location, j.salary, j.job_type
            FROM jobs j
            JOIN companies c ON j.company_id=c.company_id
            ORDER BY j.job_id DESC
        """, fetch=True)
