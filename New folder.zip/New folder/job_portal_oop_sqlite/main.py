from gui import JobPortalApp

if __name__ == "__main__":
    app = JobPortalApp()
    app.run()
