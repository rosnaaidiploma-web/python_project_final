-- Optional: view the database design manually.

CREATE TABLE users (
    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    phone TEXT,
    user_type TEXT NOT NULL
);

CREATE TABLE job_seekers (
    seeker_id INTEGER PRIMARY KEY,
    qualification TEXT,
    skills TEXT,
    experience TEXT,
    resume TEXT,
    preferred_location TEXT,
    FOREIGN KEY (seeker_id) REFERENCES users(user_id)
);

CREATE TABLE companies (
    company_id INTEGER PRIMARY KEY AUTOINCREMENT,
    recruiter_id INTEGER NOT NULL,
    company_name TEXT NOT NULL,
    industry TEXT,
    location TEXT,
    description TEXT,
    FOREIGN KEY (recruiter_id) REFERENCES users(user_id)
);

CREATE TABLE jobs (
    job_id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER NOT NULL,
    job_title TEXT NOT NULL,
    description TEXT,
    skills TEXT,
    qualification TEXT,
    location TEXT,
    salary TEXT,
    job_type TEXT,
    deadline TEXT,
    FOREIGN KEY (company_id) REFERENCES companies(company_id)
);

CREATE TABLE applications (
    application_id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id INTEGER NOT NULL,
    seeker_id INTEGER NOT NULL,
    applied_date TEXT NOT NULL,
    status TEXT DEFAULT 'Applied',
    UNIQUE(job_id, seeker_id),
    FOREIGN KEY (job_id) REFERENCES jobs(job_id),
    FOREIGN KEY (seeker_id) REFERENCES job_seekers(seeker_id)
);
