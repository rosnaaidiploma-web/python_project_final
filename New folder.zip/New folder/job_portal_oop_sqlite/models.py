from dataclasses import dataclass


@dataclass
class User:
    name: str
    email: str
    password: str
    phone: str
    user_type: str


@dataclass
class JobSeeker:
    seeker_id: int
    qualification: str
    skills: str
    experience: str
    resume: str
    preferred_location: str


@dataclass
class Company:
    recruiter_id: int
    company_name: str
    industry: str
    location: str
    description: str


@dataclass
class Job:
    company_id: int
    job_title: str
    description: str
    skills: str
    qualification: str
    location: str
    salary: str
    job_type: str
    deadline: str
